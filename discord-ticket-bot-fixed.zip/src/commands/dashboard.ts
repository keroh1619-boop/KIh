// تم التطوير بواسطة كيرو

import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  EmbedBuilder,
  ColorResolvable,
  PermissionFlagsBits,
} from "discord.js";
import { db, tickets, modStats } from "../database";
import { eq, and, count, avg } from "drizzle-orm";
import { getTopMods } from "../systems/counter";
import { getGuildAverageRating } from "../systems/rating";
import { buildDashboardEmbed, buildErrorEmbed } from "../utils/embeds";
import { getLeaderboard } from "../systems/points";
import { getModStats } from "../systems/counter";
import { getModRating } from "../systems/rating";

export const data = new SlashCommandBuilder()
  .setName("dashboard")
  .setDescription("عرض إحصائيات التكتات ولوحة التحكم")
  .addSubcommand((sub) =>
    sub.setName("stats").setDescription("إحصائيات عامة للسيرفر")
  )
  .addSubcommand((sub) =>
    sub
      .setName("mod")
      .setDescription("إحصائيات وسيط معين")
      .addUserOption((opt) =>
        opt.setName("user").setDescription("الوسيط").setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub.setName("leaderboard").setDescription("قائمة الصدارة للنقاط")
  );

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  const subcommand = interaction.options.getSubcommand();
  const guildId = interaction.guildId!;

  await interaction.deferReply();

  if (subcommand === "stats") {
    const openResult = await db
      .select({ total: count(tickets.id) })
      .from(tickets)
      .where(and(eq(tickets.guildId, guildId), eq(tickets.status, "open")));

    const inProgressResult = await db
      .select({ total: count(tickets.id) })
      .from(tickets)
      .where(and(eq(tickets.guildId, guildId), eq(tickets.status, "in_progress")));

    const closedResult = await db
      .select({ total: count(tickets.id) })
      .from(tickets)
      .where(and(eq(tickets.guildId, guildId), eq(tickets.status, "closed")));

    const totalResult = await db
      .select({ total: count(tickets.id) })
      .from(tickets)
      .where(eq(tickets.guildId, guildId));

    const openCount = Number(openResult[0]?.total ?? 0);
    const inProgressCount = Number(inProgressResult[0]?.total ?? 0);
    const closedCount = Number(closedResult[0]?.total ?? 0);
    const totalCount = Number(totalResult[0]?.total ?? 0);
    const topMods = await getTopMods(guildId, 5);
    const avgRating = await getGuildAverageRating(guildId);

    const embed = buildDashboardEmbed({
      openTickets: openCount + inProgressCount,
      closedTickets: closedCount,
      totalTickets: totalCount,
      topMods,
      avgRating,
    });

    await interaction.editReply({ embeds: [embed] });
  } else if (subcommand === "mod") {
    const targetUser = interaction.options.getUser("user") || interaction.user;
    const stats = await getModStats(targetUser.id, guildId);
    const rating = await getModRating(targetUser.id, guildId);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2 as ColorResolvable)
      .setTitle(`📊 إحصائيات الوسيط — ${targetUser.username}`)
      .setThumbnail(targetUser.displayAvatarURL())
      .addFields(
        { name: "📅 اليوم", value: `${stats.daily} تكت`, inline: true },
        { name: "📆 الأسبوع", value: `${stats.weekly} تكت`, inline: true },
        { name: "📦 الإجمالي", value: `${stats.total} تكت`, inline: true },
        {
          name: "⭐ متوسط التقييم",
          value: `${rating.avg.toFixed(1)} / 5.0 (${rating.count} تقييم)`,
          inline: false,
        }
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  } else if (subcommand === "leaderboard") {
    const leaderboard = await getLeaderboard(guildId, 10);
    const medals = ["🥇", "🥈", "🥉"];

    const leaderboardText =
      leaderboard.length > 0
        ? leaderboard
            .map(
              (entry, i) =>
                `${medals[i] || `${i + 1}.`} <@${entry.userId}> — **${entry.totalPoints}** نقطة`
            )
            .join("\n")
        : "لا توجد بيانات بعد";

    const embed = new EmbedBuilder()
      .setColor(0xfee75c as ColorResolvable)
      .setTitle("🏆 قائمة الصدارة — النقاط")
      .setDescription(leaderboardText)
      .setFooter({ text: "يحصل الوسيط على نقاط عند الموافقة على إغلاق التكتات" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
}
