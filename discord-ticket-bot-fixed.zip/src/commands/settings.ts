// تم التطوير بواسطة كيرو

import {
    SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits,
    ChannelType, EmbedBuilder, ColorResolvable,
  } from "discord.js";
  import { db, serverSettings, ticketTypeSettings } from "../database";
  import { eq, and } from "drizzle-orm";
  import { isAdmin, isOwner } from "../utils/permissions";
  import { buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
  import { TICKET_TYPES, getTicketTypeLabel } from "../utils/constants";

  const typeChoices = TICKET_TYPES.map((t) => ({ name: `${t.emoji} ${t.label}`, value: t.key }));

  export const data = new SlashCommandBuilder()
    .setName("settings")
    .setDescription("إدارة كل إعدادات البوت من مكان واحد")
    .addSubcommand((sub) => sub.setName("view").setDescription("عرض جميع الإعدادات الحالية"))
    .addSubcommand((sub) =>
      sub.setName("log").setDescription("تحديد روم اللوج")
        .addChannelOption((o) => o.setName("channel").setDescription("الروم").setRequired(true).addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((sub) =>
      sub.setName("transcript").setDescription("تحديد روم الـ Transcripts")
        .addChannelOption((o) => o.setName("channel").setDescription("الروم").setRequired(true).addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((sub) =>
      sub.setName("category").setDescription("تحديد تصنيف رومات التكتات العادية")
        .addChannelOption((o) => o.setName("category").setDescription("التصنيف").setRequired(true).addChannelTypes(ChannelType.GuildCategory))
    )
    .addSubcommand((sub) =>
      sub.setName("defamation_category").setDescription("تحديد تصنيف رومات تكتات التشهير")
        .addChannelOption((o) => o.setName("category").setDescription("التصنيف").setRequired(true).addChannelTypes(ChannelType.GuildCategory))
    )
    .addSubcommand((sub) =>
      sub.setName("tech_category").setDescription("تحديد تصنيف رومات تكتات الدعم الفني")
        .addChannelOption((o) => o.setName("category").setDescription("التصنيف").setRequired(true).addChannelTypes(ChannelType.GuildCategory))
    )
    .addSubcommand((sub) =>
      sub.setName("support_role").setDescription("إضافة رول وسطاء — الأونر فقط")
        .addRoleOption((o) => o.setName("role").setDescription("الرول").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("remove_support_role").setDescription("حذف رول وسطاء — الأونر فقط")
        .addRoleOption((o) => o.setName("role").setDescription("الرول").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("mediator_role").setDescription("تحديد رول الوسيط الرسمي — الأونر فقط")
        .addRoleOption((o) => o.setName("role").setDescription("رول الوسيط").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("permission_role").setDescription("تحديد رول مسؤول الأذونات — الأونر فقط")
        .addRoleOption((o) => o.setName("role").setDescription("الرول").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("high_admin_role").setDescription("تحديد رول المشرف الأعلى — الأونر فقط")
        .addRoleOption((o) => o.setName("role").setDescription("رول المشرف الأعلى").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("ticket_role")
        .setDescription("تحديد الرول الذي يُنشن عند فتح نوع تكت معين — الأونر فقط")
        .addStringOption((o) =>
          o.setName("type").setDescription("نوع التكت").setRequired(true).addChoices(...typeChoices)
        )
        .addRoleOption((o) => o.setName("role").setDescription("الرول").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("ticket_desc")
        .setDescription("تحديد الوصف الذي يظهر عند فتح نوع تكت معين — الأونر فقط")
        .addStringOption((o) =>
          o.setName("type").setDescription("نوع التكت").setRequired(true).addChoices(...typeChoices)
        )
        .addStringOption((o) =>
          o.setName("text").setDescription("الوصف (ما يظهر في الروم عند الفتح)").setRequired(true).setMaxLength(500)
        )
    )
    .addSubcommand((sub) =>
      sub.setName("ticket_types").setDescription("عرض إعدادات أنواع التكتات")
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild);

  export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
    if (!isAdmin(interaction.member as any)) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط للمديرين.")], ephemeral: true });
      return;
    }

    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId!;

    const ownerOnlyCommands = [
      "support_role", "remove_support_role", "mediator_role",
      "permission_role", "high_admin_role", "ticket_role", "ticket_desc",
    ];
    if (ownerOnlyCommands.includes(sub) && !isOwner(interaction.user.id)) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ هذا الأمر متاح للأونر فقط.")], ephemeral: true });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    let settings = await db.query.serverSettings.findFirst({ where: eq(serverSettings.guildId, guildId) });
    if (!settings) {
      [settings] = await db.insert(serverSettings).values({ guildId }).returning();
    }

    if (sub === "view") {
      const embed = new EmbedBuilder()
        .setColor(0x5865f2 as ColorResolvable)
        .setTitle("⚙️ إعدادات السيرفر الكاملة")
        .addFields(
          { name: "📋 روم اللوج", value: settings.logChannelId ? `<#${settings.logChannelId}>` : "غير محدد", inline: true },
          { name: "📁 روم Transcripts", value: settings.transcriptChannelId ? `<#${settings.transcriptChannelId}>` : "غير محدد", inline: true },
          { name: "📂 تصنيف التكتات", value: settings.ticketCategoryId ? `<#${settings.ticketCategoryId}>` : "غير محدد", inline: true },
          { name: "⚠️ تصنيف التشهير", value: settings.defamationCategoryId ? `<#${settings.defamationCategoryId}>` : "غير محدد", inline: true },
          { name: "🔧 تصنيف الدعم الفني", value: settings.techSupportCategoryId ? `<#${settings.techSupportCategoryId}>` : "غير محدد", inline: true },
          { name: "👥 أدوار الوسطاء", value: settings.supportRoleIds?.length ? settings.supportRoleIds.map(r => `<@&${r}>`).join(", ") : "لا يوجد", inline: false },
          { name: "🤝 رول الوسيط الرسمي", value: settings.mediatorRoleId ? `<@&${settings.mediatorRoleId}>` : "غير محدد", inline: true },
          { name: "🔐 رول مسؤول الأذونات", value: settings.permissionManagerRoleId ? `<@&${settings.permissionManagerRoleId}>` : "غير محدد", inline: true },
          { name: "🛡️ رول المشرف الأعلى", value: settings.highAdminRoleId ? `<@&${settings.highAdminRoleId}>` : "غير محدد", inline: true },
        ).setTimestamp();
      await interaction.editReply({ embeds: [embed] });

    } else if (sub === "log") {
      const ch = interaction.options.getChannel("channel")!;
      await db.update(serverSettings).set({ logChannelId: ch.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد <#${ch.id}> كروم اللوج.`)] });

    } else if (sub === "transcript") {
      const ch = interaction.options.getChannel("channel")!;
      await db.update(serverSettings).set({ transcriptChannelId: ch.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد <#${ch.id}> كروم الـ Transcripts.`)] });

    } else if (sub === "category") {
      const cat = interaction.options.getChannel("category")!;
      await db.update(serverSettings).set({ ticketCategoryId: cat.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد تصنيف التكتات العادية: **${cat.name}**.`)] });

    } else if (sub === "defamation_category") {
      const cat = interaction.options.getChannel("category")!;
      await db.update(serverSettings).set({ defamationCategoryId: cat.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد تصنيف تكتات التشهير: **${cat.name}**.`)] });

    } else if (sub === "tech_category") {
      const cat = interaction.options.getChannel("category")!;
      await db.update(serverSettings).set({ techSupportCategoryId: cat.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد تصنيف تكتات الدعم الفني: **${cat.name}**.`)] });

    } else if (sub === "support_role") {
      const role = interaction.options.getRole("role")!;
      const current = settings.supportRoleIds ?? [];
      if (!current.includes(role.id)) current.push(role.id);
      await db.update(serverSettings).set({ supportRoleIds: current, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم إضافة <@&${role.id}> كرول وسطاء.`)] });

    } else if (sub === "remove_support_role") {
      const role = interaction.options.getRole("role")!;
      const current = (settings.supportRoleIds ?? []).filter(r => r !== role.id);
      await db.update(serverSettings).set({ supportRoleIds: current, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم حذف <@&${role.id}> من أدوار الوسطاء.`)] });

    } else if (sub === "mediator_role") {
      const role = interaction.options.getRole("role")!;
      await db.update(serverSettings).set({ mediatorRoleId: role.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد <@&${role.id}> كرول الوسيط الرسمي.`)] });

    } else if (sub === "permission_role") {
      const role = interaction.options.getRole("role")!;
      await db.update(serverSettings).set({ permissionManagerRoleId: role.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد <@&${role.id}> كرول مسؤول الأذونات.`)] });

    } else if (sub === "high_admin_role") {
      const role = interaction.options.getRole("role")!;
      await db.update(serverSettings).set({ highAdminRoleId: role.id, updatedAt: new Date() }).where(eq(serverSettings.guildId, guildId));
      await interaction.editReply({ embeds: [buildSuccessEmbed(`✅ تم تحديد <@&${role.id}> كرول المشرف الأعلى. يمكنه عرض جميع التكتات والتحكم الكامل فيها.`)] });

    } else if (sub === "ticket_role") {
      const typeKey = interaction.options.getString("type", true);
      const role = interaction.options.getRole("role", true);
      const existingType = await db.query.ticketTypeSettings.findFirst({
        where: and(eq(ticketTypeSettings.guildId, guildId), eq(ticketTypeSettings.typeKey, typeKey)),
      });
      if (existingType) {
        await db.update(ticketTypeSettings)
          .set({ mentionRoleId: role.id, updatedAt: new Date() })
          .where(eq(ticketTypeSettings.id, existingType.id));
      } else {
        await db.insert(ticketTypeSettings).values({ guildId, typeKey, mentionRoleId: role.id, updatedAt: new Date() });
      }
      await interaction.editReply({
        embeds: [buildSuccessEmbed(
          `✅ سيتم منشنة <@&${role.id}> عند فتح تكت **${getTicketTypeLabel(typeKey)}**.`
        )],
      });

    } else if (sub === "ticket_desc") {
      const typeKey = interaction.options.getString("type", true);
      const text = interaction.options.getString("text", true);
      const existingType2 = await db.query.ticketTypeSettings.findFirst({
        where: and(eq(ticketTypeSettings.guildId, guildId), eq(ticketTypeSettings.typeKey, typeKey)),
      });
      if (existingType2) {
        await db.update(ticketTypeSettings)
          .set({ description: text, updatedAt: new Date() })
          .where(eq(ticketTypeSettings.id, existingType2.id));
      } else {
        await db.insert(ticketTypeSettings).values({ guildId, typeKey, description: text, updatedAt: new Date() });
      }
      await interaction.editReply({
        embeds: [buildSuccessEmbed(
          `✅ تم تحديد وصف **${getTicketTypeLabel(typeKey)}**:\n\`\`\`${text}\`\`\``
        )],
      });

    } else if (sub === "ticket_types") {
      const allTypes = await db.query.ticketTypeSettings.findMany({
        where: eq(ticketTypeSettings.guildId, guildId),
      });
      const typeMap = new Map(allTypes.map((t) => [t.typeKey, t]));

      const fields = TICKET_TYPES.map((t) => {
        const cfg = typeMap.get(t.key);
        return {
          name: `${t.emoji} ${t.label}`,
          value: [
            `🔔 الرول: ${cfg?.mentionRoleId ? `<@&${cfg.mentionRoleId}>` : "غير محدد"}`,
            `📝 الوصف: ${cfg?.description ? cfg.description.slice(0, 80) : "غير محدد"}`,
          ].join("\n"),
          inline: false,
        };
      });

      const embed = new EmbedBuilder()
        .setColor(0x5865f2 as ColorResolvable)
        .setTitle("🎫 إعدادات أنواع التكتات")
        .addFields(...fields)
        .setFooter({ text: "استخدم /settings ticket_role و /settings ticket_desc للتعديل" })
        .setTimestamp();
      await interaction.editReply({ embeds: [embed] });
    }
  }
