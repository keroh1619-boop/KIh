// تم التطوير بواسطة كيرو

import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { isOwner } from "../utils/permissions";
import { buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
import { bulkCloseTickets } from "../systems/tickets";
import { sendLog } from "../systems/logging";

export const data = new SlashCommandBuilder()
  .setName("bulkclose")
  .setDescription("إغلاق وحذف جميع التكتات المفتوحة (للأونر فقط)")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!isOwner(interaction.user.id)) {
    await interaction.reply({
      embeds: [buildErrorEmbed("🔐 هذا الأمر متاح فقط لصاحب السيرفر.")],
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const guildId = interaction.guildId!;
  const result = await bulkCloseTickets(interaction.client, guildId, interaction.user.id);

  await sendLog(interaction.client, guildId, "bulk_close", [
    { name: "🔴 تكتات مغلقة", value: `${result.closed}`, inline: true },
    { name: "🗑️ رومات محذوفة", value: `${result.deleted}`, inline: true },
    { name: "👤 بواسطة", value: `<@${interaction.user.id}>`, inline: true },
  ], undefined, interaction.user.id);

  await interaction.editReply({
    embeds: [buildSuccessEmbed(
      `✅ تم إغلاق **${result.closed}** تكت وحذف **${result.deleted}** روم بنجاح.`
    )],
  });
}
