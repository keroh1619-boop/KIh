// تم التطوير بواسطة كيرو

import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { requestApproval } from "../systems/approval";

export const data = new SlashCommandBuilder()
  .setName("اذن")
  .setDescription("طلب إذن بدء الوساطة من مسؤول الأذونات أو الأونر");

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  await requestApproval(interaction);
}
