import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { isOwner } from "../utils/permissions";
import { resetModStats } from "../systems/counter";
import { resetPoints } from "../systems/points";
import { buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
import { sendLog } from "../systems/logging";

// ============================================================
// أمر /reset — إصفار الإحصائيات (للأونر فقط)
// ============================================================

export const data = new SlashCommandBuilder()
  .setName("reset")
  .setDescription("إصفار إحصائيات الوسطاء (للأونر فقط)")
  .addSubcommand((sub) =>
    sub.setName("stats").setDescription("إصفار عدادات التكتات لجميع الوسطاء")
  )
  .addSubcommand((sub) =>
    sub.setName("points").setDescription("إصفار نقاط جميع الوسطاء")
  )
  .addSubcommand((sub) =>
    sub.setName("all").setDescription("إصفار كل شيء (العدادات والنقاط)")
  )
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator);

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  // هذا الأمر للأونر فقط
  if (!isOwner(interaction.user.id)) {
    await interaction.reply({
      embeds: [buildErrorEmbed("🔐 هذا الأمر متاح فقط لصاحب السيرفر.")],
      ephemeral: true,
    });
    return;
  }

  const subcommand = interaction.options.getSubcommand();
  const guildId = interaction.guildId!;

  await interaction.deferReply({ ephemeral: true });

  if (subcommand === "stats" || subcommand === "all") {
    await resetModStats(guildId);
  }

  if (subcommand === "points" || subcommand === "all") {
    await resetPoints(guildId);
  }

  const resetType =
    subcommand === "stats"
      ? "العدادات"
      : subcommand === "points"
      ? "النقاط"
      : "العدادات والنقاط";

  await sendLog(
    interaction.client,
    guildId,
    "mod_reset",
    [
      { name: "🔄 نوع الإصفار", value: resetType, inline: true },
      { name: "👤 بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ],
    undefined,
    interaction.user.id
  );

  await interaction.editReply({
    embeds: [buildSuccessEmbed(`✅ تم إصفار **${resetType}** لجميع الوسطاء بنجاح.`)],
  });
}
