import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { db, tickets } from "../database";
import { eq } from "drizzle-orm";
import { buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
import { checkCooldown } from "../systems/cooldown";
import { isModerator } from "../utils/permissions";
import { GuildMember } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("come")
  .setDescription("استدعاء صاحب التكت أو شخص معين عبر الرسائل الخاصة")
  .addUserOption((opt) =>
    opt.setName("user").setDescription("المستخدم المراد استدعاؤه (اختياري — يستدعي صاحب التكت تلقائياً)").setRequired(false)
  )
  .addStringOption((opt) =>
    opt.setName("message").setDescription("رسالة مخصصة (اختياري)").setRequired(false).setMaxLength(400)
  );

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  const member = interaction.member as GuildMember;

  if (!(await isModerator(member))) {
    await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط الوسطاء يمكنهم استخدام هذا الأمر.")], ephemeral: true });
    return;
  }

  const cooldownError = checkCooldown(interaction.user.id, "come", 30);
  if (cooldownError) {
    await interaction.reply({ embeds: [buildErrorEmbed(cooldownError)], ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser("user");
  const customMessage = interaction.options.getString("message");
  await interaction.deferReply({ ephemeral: true });

  // تحديد المستخدم المستهدف
  let recipientId: string;
  let recipientName: string;

  if (targetUser) {
    recipientId = targetUser.id;
    recipientName = targetUser.username;
  } else {
    // جلب صاحب التكت من قاعدة البيانات
    const ticket = await db.query.tickets.findFirst({
      where: eq(tickets.channelId, interaction.channelId),
    });

    if (!ticket || ticket.status === "closed") {
      await interaction.editReply({
        embeds: [buildErrorEmbed("❌ هذا الأمر متاح داخل روم تكت مفتوح، أو حدّد مستخدماً بـ `/come user:@اسم`")],
      });
      return;
    }

    recipientId = ticket.userId;
    recipientName = `صاحب التكت #${ticket.ticketNumber}`;
  }

  // إرسال DM للمستخدم
  const dmMessage = customMessage
    ?? `📣 يرجى التواصل معنا في السيرفر في أقرب وقت ممكن!\n🔗 السيرفر: **${interaction.guild?.name}**`;

  try {
    const user = await interaction.client.users.fetch(recipientId);
    await user.send({
      embeds: [{
        color: 0xffa500,
        title: "📣 تم استدعاؤك",
        description: dmMessage,
        fields: [
          { name: "📍 السيرفر", value: interaction.guild?.name ?? "غير محدد", inline: true },
          { name: "👤 أرسل بواسطة", value: `<@${interaction.user.id}>`, inline: true },
        ],
        timestamp: new Date().toISOString(),
      }],
    });
    await interaction.editReply({
      embeds: [buildSuccessEmbed(`✅ تم إرسال رسالة خاصة إلى **${recipientName}** بنجاح.`)],
    });
  } catch {
    await interaction.editReply({
      embeds: [buildErrorEmbed(`❌ تعذّر إرسال رسالة خاصة إلى **${recipientName}**.\nقد يكون أغلق الرسائل الخاصة.`)],
    });
  }
}
