// تم التطوير بواسطة كيرو

import { ChatInputCommandInteraction, SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";
import { startPanelCreation } from "../systems/panel";
import { buildErrorEmbed } from "../utils/embeds";
import { isAdmin } from "../utils/permissions";

export const data = new SlashCommandBuilder()
  .setName("panel")
  .setDescription("إنشاء بانل تكت مخصص في أي روم")
  .addChannelOption((o) =>
    o.setName("channel")
      .setDescription("الروم الذي تريد نشر البانل فيه")
      .setRequired(true)
      .addChannelTypes(ChannelType.GuildText)
  )
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild);

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!isAdmin(interaction.member as any)) {
    await interaction.reply({
      embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط للمديرين.")],
      ephemeral: true,
    });
    return;
  }

  const channel = interaction.options.getChannel("channel", true);
  await startPanelCreation(interaction, channel.id, "mediator");
}
