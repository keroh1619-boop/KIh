// تم التطوير بواسطة كيرو

import {
  SlashCommandBuilder, ChatInputCommandInteraction,
  EmbedBuilder, ColorResolvable,
} from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("help")
  .setDescription("عرض جميع أوامر البوت مع شرح لكل أمر");

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2 as ColorResolvable)
    .setTitle("📖 أوامر البوت")
    .setDescription("قائمة بجميع الأوامر المتاحة مع شرحها:")
    .addFields(
      {
        name: "🎫 أوامر التكت",
        value: [
          "`/تم` — تأكيد الانتهاء من التكت (رول الوسيط فقط) — يقفل التكت وينتظر الموافقة",
          "`/اذن` — طلب إذن بدء الوساطة (رول الوسيط فقط)",
          "`/come [user] [message]` — استدعاء شخص أو صاحب التكت",
        ].join("\n"),
        inline: false,
      },
      {
        name: "📊 الإحصائيات والتقارير",
        value: [
          "`/dashboard stats` — إحصائيات عامة للسيرفر",
          "`/dashboard mod [user]` — إحصائيات وسيط معين",
          "`/dashboard leaderboard` — قائمة صدارة النقاط",
        ].join("\n"),
        inline: false,
      },
      {
        name: "⚙️ الإعدادات (المديرون فقط)",
        value: [
          "`/settings view` — عرض جميع الإعدادات الحالية",
          "`/settings log` — تحديد روم اللوج",
          "`/settings transcript` — تحديد روم Transcripts",
          "`/settings category` — تحديد تصنيف تكتات السيرفر",
          "`/settings defamation_category` — تحديد تصنيف تكتات التشهير",
          "`/settings tech_category` — تحديد تصنيف تكتات الدعم الفني",
          "`/settings support_role` — إضافة رول دعم",
          "`/settings remove_support_role` — حذف رول دعم",
          "`/settings mediator_role` — تحديد رول الوسيط الرسمي",
          "`/settings permission_role` — تحديد رول مسؤول الأذونات",
          "`/settings high_admin_role` — تحديد رول المشرف الأعلى",
          "`/settings ticket_role` — تحديد رول لنوع تكت معين",
          "`/settings ticket_desc` — تحديد وصف لنوع تكت معين",
          "`/settings ticket_types` — عرض إعدادات أنواع التكتات",
        ].join("\n"),
        inline: false,
      },
      {
        name: "📋 البانل",
        value: [
          "`/panel channel:#روم` — إنشاء بانل تكت وسطاء",
          "`/techpanel channel:#روم` — إنشاء بانل دعم فني منفصل",
        ].join("\n"),
        inline: false,
      },
      {
        name: "🔐 أوامر الأونر فقط",
        value: [
          "`/reset stats` — إصفار عدادات التكتات لجميع الوسطاء",
          "`/reset points` — إصفار نقاط جميع الوسطاء",
          "`/reset all` — إصفار كل شيء",
          "`/bulkclose` — إغلاق وحذف جميع التكتات المفتوحة",
        ].join("\n"),
        inline: false,
      },
      {
        name: "ℹ️ ملاحظات",
        value: [
          "• أوامر `/تم` و `/اذن` تعمل **داخل رومات التكتات فقط** وتتطلب رول الوسيط",
          "• عند استخدام `/تم` يُقفل التكت وينتظر موافقة مسؤول الأذونات أو الأونر",
          "• ✅ الموافقة = إغلاق + نقاط | ❌ الرفض = إغلاق بدون نقاط",
          "• المشرف الأعلى يمكنه عرض جميع التكتات والتحكم الكامل فيها",
          "• نظام النقاط يكافئ الوسطاء عند الموافقة على إغلاق التكتات",
        ].join("\n"),
        inline: false,
      }
    )
    .setFooter({ text: "بوت تكت احترافي" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}
