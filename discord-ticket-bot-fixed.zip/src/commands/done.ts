// تم التطوير بواسطة كيرو

import { SlashCommandBuilder, ChatInputCommandInteraction } from "discord.js";
import { requestDoneApproval } from "../systems/approval";

export const data = new SlashCommandBuilder()
  .setName("تم")
  .setDescription("تأكيد الانتهاء من التكت وإرسال طلب موافقة");

export async function execute(interaction: ChatInputCommandInteraction): Promise<void> {
  await requestDoneApproval(interaction);
}
