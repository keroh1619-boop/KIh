import { Message } from "discord.js";
import { db, tickets } from "../database";
import { eq } from "drizzle-orm";
import { getAIResponse, shouldAIRespond } from "../systems/ai";

// ============================================================
// حدث MessageCreate — AI داخل التكت
// ============================================================

// تخزين سياق المحادثة (ticketId -> messages)
const conversationContexts = new Map<
  number,
  Array<{ role: "user" | "assistant"; content: string }>
>();

export async function handleMessageCreate(message: Message): Promise<void> {
  // تجاهل رسائل البوتات والرسائل خارج السيرفر
  if (message.author.bot || !message.guildId) return;

  // التحقق من أن الروم هو روم تكت مفتوح
  const ticket = await db.query.tickets.findFirst({
    where: eq(tickets.channelId, message.channelId),
  });

  if (!ticket || ticket.status === "closed") return;

  // التحقق من أن الرسالة من صاحب التكت
  if (message.author.id !== ticket.userId) return;

  // التحقق من أن الرسالة تستحق رداً AI
  if (!shouldAIRespond(message.content)) return;

  // الحصول على سياق المحادثة
  const context = conversationContexts.get(ticket.id) || [];

  try {
    const aiResponse = await getAIResponse(message.content, context);
    if (!aiResponse) return;

    // تحديث السياق
    context.push({ role: "user", content: message.content });
    context.push({ role: "assistant", content: aiResponse });

    // الاحتفاظ بآخر 10 رسائل فقط
    if (context.length > 10) context.splice(0, context.length - 10);
    conversationContexts.set(ticket.id, context);

    // الرد في نفس الروم
    await message.reply({
      content: `🤖 **ردّ تلقائي:**\n${aiResponse}\n\n*إذا لم تجد إجابة كافية، سيتواصل معك الفريق قريباً.*`,
    });
  } catch (error) {
    console.error("خطأ في رد AI:", error);
  }
}
