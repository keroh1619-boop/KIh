// تم التطوير بواسطة كيرو

import {
  Interaction, ButtonInteraction, StringSelectMenuInteraction,
  ModalSubmitInteraction, ChatInputCommandInteraction,
} from "discord.js";
import { db, tickets } from "../database";
import { eq } from "drizzle-orm";

import * as panelCommand from "../commands/panel";
import * as techpanelCommand from "../commands/techpanel";
import * as dashboardCommand from "../commands/dashboard";
import * as comeCommand from "../commands/come";
import * as resetCommand from "../commands/reset";
import * as doneCommand from "../commands/done";
import * as permissionCommand from "../commands/permission_cmd";
import * as settingsCommand from "../commands/settings";
import * as helpCommand from "../commands/help";
import * as bulkcloseCommand from "../commands/bulkclose";

import { createTicket, closeTicket, updateTicketPriority } from "../systems/tickets";
import { claimTicket, unclaimTicket } from "../systems/claim";
import { handlePanelModal, cancelPanel, getPanelById } from "../systems/panel";
import { saveRating, hasRated } from "../systems/rating";
import { buildErrorEmbed, buildSuccessEmbed, buildTicketTypeMenu } from "../utils/embeds";
import { acceptApproval, rejectApproval, handleDoneApprove, handleDoneReject } from "../systems/approval";
import { TECH_SUPPORT_TYPE_KEY } from "../utils/constants";

interface Command {
  data: { name: string; toJSON: () => unknown };
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

const commands = new Map<string, Command>([
  ["panel", panelCommand as Command],
  ["techpanel", techpanelCommand as Command],
  ["dashboard", dashboardCommand as Command],
  ["come", comeCommand as Command],
  ["reset", resetCommand as Command],
  ["تم", doneCommand as Command],
  ["اذن", permissionCommand as Command],
  ["settings", settingsCommand as Command],
  ["help", helpCommand as Command],
  ["bulkclose", bulkcloseCommand as Command],
]);

export async function handleInteractionCreate(interaction: Interaction): Promise<void> {
  try {
    if (interaction.isChatInputCommand()) {
      const command = commands.get(interaction.commandName);
      if (command) await command.execute(interaction as ChatInputCommandInteraction);
      return;
    }
    if (interaction.isButton()) { await handleButton(interaction as ButtonInteraction); return; }
    if (interaction.isStringSelectMenu()) { await handleSelectMenu(interaction as StringSelectMenuInteraction); return; }
    if (interaction.isModalSubmit()) { await handleModal(interaction as ModalSubmitInteraction); return; }
  } catch (error: unknown) {
    const err = error as { message?: string; code?: string };
    console.error("❌ خطأ في التفاعل:", interaction.isCommand() ? (interaction as ChatInputCommandInteraction).commandName : "", err?.message || error);

    let errorMessage = "❌ حدث خطأ غير متوقع. يرجى المحاولة مجدداً.";
    if (err?.message?.includes("connect") || err?.message?.includes("database") || err?.code === "ECONNREFUSED") {
      errorMessage = "❌ تعذّر الاتصال بقاعدة البيانات.\n📌 تأكد من صحة `DATABASE_URL` في ملف .env وشغّل: `npm run db:push`";
    } else if (err?.message?.includes("relation") || err?.message?.includes("does not exist")) {
      errorMessage = "❌ جداول قاعدة البيانات غير موجودة.\n📌 شغّل الأمر: `npm run db:push` ثم أعد تشغيل البوت.";
    }

    try {
      if (interaction.isRepliable()) {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [buildErrorEmbed(errorMessage)], ephemeral: true });
        } else {
          await interaction.reply({ embeds: [buildErrorEmbed(errorMessage)], ephemeral: true });
        }
      }
    } catch {}
  }
}

async function handleButton(interaction: ButtonInteraction): Promise<void> {
  if (interaction.customId.startsWith("done_approve_")) {
    const parts = interaction.customId.split("_");
    const ticketId = parseInt(parts[2]);
    const mediatorId = parts[3];
    await handleDoneApprove(interaction, ticketId, mediatorId);
    return;
  }
  if (interaction.customId.startsWith("done_reject_")) {
    const parts = interaction.customId.split("_");
    const ticketId = parseInt(parts[2]);
    const mediatorId = parts[3];
    await handleDoneReject(interaction, ticketId, mediatorId);
    return;
  }

  if (interaction.customId.startsWith("approval_accept_")) {
    const parts = interaction.customId.split("_");
    const ticketId = parseInt(parts[2]);
    const mediatorId = parts[3];
    await acceptApproval(interaction, ticketId, mediatorId);
    return;
  }
  if (interaction.customId.startsWith("approval_reject_")) {
    const parts = interaction.customId.split("_");
    const ticketId = parseInt(parts[2]);
    const mediatorId = parts[3];
    await rejectApproval(interaction, ticketId, mediatorId);
    return;
  }

  if (interaction.customId.startsWith("panel_open_")) {
    const parts = interaction.customId.split("_");
    const panelId = parseInt(parts[2]);
    const panel = panelId ? await getPanelById(panelId) : null;
    if (!panel) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ البانل غير موجود أو تم حذفه.")], ephemeral: true });
      return;
    }
    await interaction.reply({ content: "🎯 يرجى اختيار نوع التكت:", components: [buildTicketTypeMenu(panelId)], ephemeral: true });
    return;
  }

  if (interaction.customId.startsWith("techpanel_open_")) {
    const parts = interaction.customId.split("_");
    const panelId = parseInt(parts[2]);
    const panel = panelId ? await getPanelById(panelId) : null;
    if (!panel) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ البانل غير موجود أو تم حذفه.")], ephemeral: true });
      return;
    }
    await createTicket(interaction, panelId, TECH_SUPPORT_TYPE_KEY);
    return;
  }

  if (interaction.customId === "panel_cancel") { await cancelPanel(interaction); return; }

  if (interaction.customId.startsWith("ticket_")) {
    const parts = interaction.customId.split("_");
    const btnAction = parts[1];
    const ticketId = parseInt(parts[2]);
    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket) { await interaction.reply({ embeds: [buildErrorEmbed("❌ التكت غير موجود.")], ephemeral: true }); return; }
    if (ticket.status === "closed") { await interaction.reply({ embeds: [buildErrorEmbed("❌ هذا التكت مغلق بالفعل.")], ephemeral: true }); return; }
    switch (btnAction) {
      case "claim": await claimTicket(interaction, ticket); break;
      case "unclaim": await unclaimTicket(interaction, ticket); break;
      case "close": await closeTicket(interaction, ticket); break;
    }
    return;
  }

  if (interaction.customId.startsWith("rating_")) {
    const parts = interaction.customId.split("_");
    const ticketId = parseInt(parts[1]);
    const ratingValue = parseInt(parts[2]);
    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket || ticket.status !== "closed") {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لا يمكن تقييم هذا التكت.")], ephemeral: true });
      return;
    }
    if (await hasRated(ticketId, interaction.user.id)) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لقد قيّمت هذا التكت بالفعل.")], ephemeral: true });
      return;
    }
    const modId = ticket.claimedBy || ticket.assignedTo || "";
    if (modId) {
      await saveRating(ticketId, ticket.guildId, interaction.user.id, modId, ratingValue);
      const { sendLog } = await import("../systems/logging");
      await sendLog(interaction.client, ticket.guildId, "ticket_rate", [
        { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
        { name: "⭐ التقييم", value: `${"⭐".repeat(ratingValue)} (${ratingValue}/5)`, inline: true },
        { name: "🤖 الوسيط", value: `<@${modId}>`, inline: true },
      ], ticket.id, interaction.user.id, modId);
    }
    await interaction.update({
      embeds: [buildSuccessEmbed(`شكراً على تقييمك! ${"⭐".repeat(ratingValue)}\nتقييمك يساعدنا في تحسين الخدمة.`)],
      components: [],
    });
    return;
  }
}

async function handleSelectMenu(interaction: StringSelectMenuInteraction): Promise<void> {
  if (interaction.customId.startsWith("ticket_type_")) {
    const panelId = parseInt(interaction.customId.split("_")[2]);
    await createTicket(interaction, panelId, interaction.values[0]);
    return;
  }
  if (interaction.customId.startsWith("ticket_priority_")) {
    const ticketId = parseInt(interaction.customId.split("_")[2]);
    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (ticket) await updateTicketPriority(interaction, ticket, interaction.values[0]);
    return;
  }
}

async function handleModal(interaction: ModalSubmitInteraction): Promise<void> {
  if (interaction.customId === "panel_create_modal_mediator") {
    await handlePanelModal(interaction, "mediator");
  } else if (interaction.customId === "panel_create_modal_tech_support") {
    await handlePanelModal(interaction, "tech_support");
  }
}
