import {
    pgTable, serial, text, integer, boolean,
    timestamp, jsonb, uniqueIndex,
  } from "drizzle-orm/pg-core";

  export const serverSettings = pgTable("server_settings", {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull().unique(),
    logChannelId: text("log_channel_id"),
    transcriptChannelId: text("transcript_channel_id"),
    ticketCategoryId: text("ticket_category_id"),
    defamationCategoryId: text("defamation_category_id"),
    techSupportCategoryId: text("tech_support_category_id"),
    supportRoleIds: text("support_role_ids").array().default([]),
    mediatorRoleId: text("mediator_role_id"),
    permissionManagerRoleId: text("permission_manager_role_id"),
    highAdminRoleId: text("high_admin_role_id"),
    prefix: text("prefix").default("!"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  });

  export const tickets = pgTable("tickets", {
    id: serial("id").primaryKey(),
    ticketNumber: integer("ticket_number").notNull(),
    guildId: text("guild_id").notNull(),
    channelId: text("channel_id").notNull().unique(),
    userId: text("user_id").notNull(),
    claimedBy: text("claimed_by"),
    assignedTo: text("assigned_to"),
    status: text("status").notNull().default("open"),
    priority: text("priority").notNull().default("medium"),
    ticketType: text("ticket_type"),
    panelMessageId: text("panel_message_id"),
    unclaimedBy: text("unclaimed_by").array().default([]),
    blockedMediators: text("blocked_mediators").array().default([]),
    closedBy: text("closed_by"),
    approvedBy: text("approved_by"),
    doneBy: text("done_by"),
    closedAt: timestamp("closed_at"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  });

  export const ticketPanels = pgTable("ticket_panels", {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    channelId: text("channel_id").notNull(),
    messageId: text("message_id").notNull(),
    panelType: text("panel_type").notNull().default("mediator"),
    title: text("title").notNull().default("🎫 فتح تكت"),
    description: text("description").notNull().default("اضغط على الزر أدناه لفتح تكت دعم"),
    color: text("color").notNull().default("#5865F2"),
    buttonLabel: text("button_label").notNull().default("📩 فتح تكت"),
    imageUrl: text("image_url"),
    thumbnailUrl: text("thumbnail_url"),
    footerText: text("footer_text"),
    createdBy: text("created_by").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  });

  export const modStats = pgTable("mod_stats", {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    guildId: text("guild_id").notNull(),
    dailyCount: integer("daily_count").notNull().default(0),
    weeklyCount: integer("weekly_count").notNull().default(0),
    totalCount: integer("total_count").notNull().default(0),
    lastDailyReset: timestamp("last_daily_reset").defaultNow(),
    lastWeeklyReset: timestamp("last_weekly_reset").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  }, (table) => ({
    uniqueUserGuild: uniqueIndex("mod_stats_user_guild_unique").on(table.userId, table.guildId),
  }));

  export const ratings = pgTable("ratings", {
    id: serial("id").primaryKey(),
    ticketId: integer("ticket_id").notNull(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    modId: text("mod_id").notNull(),
    rating: integer("rating").notNull(),
    comment: text("comment"),
    createdAt: timestamp("created_at").defaultNow(),
  });

  export const points = pgTable("points", {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    guildId: text("guild_id").notNull(),
    totalPoints: integer("total_points").notNull().default(0),
    updatedAt: timestamp("updated_at").defaultNow(),
  }, (table) => ({
    uniqueUserGuild: uniqueIndex("points_user_guild_unique").on(table.userId, table.guildId),
  }));

  export const antiSpam = pgTable("anti_spam", {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    guildId: text("guild_id").notNull(),
    lastTicketAt: timestamp("last_ticket_at").defaultNow(),
    attemptCount: integer("attempt_count").notNull().default(0),
  }, (table) => ({
    uniqueUserGuild: uniqueIndex("anti_spam_user_guild_unique").on(table.userId, table.guildId),
  }));

  export const eventLogs = pgTable("event_logs", {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    ticketId: integer("ticket_id"),
    eventType: text("event_type").notNull(),
    actorId: text("actor_id"),
    targetId: text("target_id"),
    details: jsonb("details"),
    createdAt: timestamp("created_at").defaultNow(),
  });

  export const ticketTypeSettings = pgTable("ticket_type_settings", {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    typeKey: text("type_key").notNull(),
    mentionRoleId: text("mention_role_id"),
    description: text("description"),
    updatedAt: timestamp("updated_at").defaultNow(),
  }, (table) => ({
    uniqueGuildType: uniqueIndex("ticket_type_settings_guild_type_unique").on(table.guildId, table.typeKey),
  }));

  export const transcripts = pgTable("transcripts", {
    id: serial("id").primaryKey(),
    ticketId: integer("ticket_id").notNull(),
    guildId: text("guild_id").notNull(),
    content: text("content").notNull(),
    format: text("format").notNull().default("html"),
    createdAt: timestamp("created_at").defaultNow(),
  });

  export type ServerSettings = typeof serverSettings.$inferSelect;
  export type InsertServerSettings = typeof serverSettings.$inferInsert;
  export type Ticket = typeof tickets.$inferSelect;
  export type InsertTicket = typeof tickets.$inferInsert;
  export type TicketPanel = typeof ticketPanels.$inferSelect;
  export type InsertTicketPanel = typeof ticketPanels.$inferInsert;
  export type ModStat = typeof modStats.$inferSelect;
  export type Rating = typeof ratings.$inferSelect;
  export type Point = typeof points.$inferSelect;
  export type AntiSpamRecord = typeof antiSpam.$inferSelect;
  export type EventLog = typeof eventLogs.$inferSelect;
  export type Transcript = typeof transcripts.$inferSelect;
  export type TicketTypeSetting = typeof ticketTypeSettings.$inferSelect;
