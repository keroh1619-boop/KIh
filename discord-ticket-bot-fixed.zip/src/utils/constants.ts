// تم التطوير بواسطة كيرو

export const TICKET_TYPES = [
  { key: "mediator_ticket",     label: "تكت وسطاء",    emoji: "📋" },
  { key: "mediator_defamation", label: "تشهير وسطاء",  emoji: "⚠️" },
] as const;

export const TECH_SUPPORT_TYPE_KEY = "technical_support";
export const TECH_SUPPORT_LABEL = "دعم فني";

export type TicketTypeKey = typeof TICKET_TYPES[number]["key"] | typeof TECH_SUPPORT_TYPE_KEY;

export function getTicketTypeLabel(key: string): string {
  if (key === TECH_SUPPORT_TYPE_KEY) return TECH_SUPPORT_LABEL;
  return TICKET_TYPES.find((t) => t.key === key)?.label ?? key;
}
