// تم التطوير بواسطة كيرو

import { GuildMember, PermissionFlagsBits } from "discord.js";
import { config } from "../config";
import { db, serverSettings } from "../database";
import { eq } from "drizzle-orm";

export function isOwner(userId: string): boolean {
  return userId === config.ownerId;
}

export function isAdmin(member: GuildMember): boolean {
  return (
    member.permissions.has(PermissionFlagsBits.Administrator) ||
    member.permissions.has(PermissionFlagsBits.ManageGuild)
  );
}

async function fetchFullMember(member: GuildMember): Promise<GuildMember> {
  try {
    return await member.guild.members.fetch(member.id);
  } catch {
    return member;
  }
}

export async function isModerator(member: GuildMember): Promise<boolean> {
  if (isOwner(member.id)) return true;

  const settings = await db.query.serverSettings.findFirst({
    where: eq(serverSettings.guildId, member.guild.id),
  });

  if (!settings?.supportRoleIds || settings.supportRoleIds.length === 0) {
    return false;
  }

  const fullMember = await fetchFullMember(member);
  const memberRoleIds = [...fullMember.roles.cache.keys()];

  return settings.supportRoleIds.some((roleId) => memberRoleIds.includes(roleId));
}

export async function hasMediatorRole(member: GuildMember): Promise<boolean> {
  if (isOwner(member.id)) return true;

  const settings = await db.query.serverSettings.findFirst({
    where: eq(serverSettings.guildId, member.guild.id),
  });

  if (!settings?.mediatorRoleId) return false;

  const fullMember = await fetchFullMember(member);
  return fullMember.roles.cache.has(settings.mediatorRoleId);
}

export async function isHighAdmin(member: GuildMember): Promise<boolean> {
  if (isOwner(member.id)) return true;

  const settings = await db.query.serverSettings.findFirst({
    where: eq(serverSettings.guildId, member.guild.id),
  });

  if (!settings?.highAdminRoleId) return false;

  const fullMember = await fetchFullMember(member);
  return fullMember.roles.cache.has(settings.highAdminRoleId);
}

export async function isPermissionManager(member: GuildMember): Promise<boolean> {
  if (isOwner(member.id)) return true;

  const settings = await db.query.serverSettings.findFirst({
    where: eq(serverSettings.guildId, member.guild.id),
  });

  if (!settings?.permissionManagerRoleId) return false;

  const fullMember = await fetchFullMember(member);
  return fullMember.roles.cache.has(settings.permissionManagerRoleId);
}

export function isTicketOwner(userId: string, ticketUserId: string): boolean {
  return userId === ticketUserId;
}
