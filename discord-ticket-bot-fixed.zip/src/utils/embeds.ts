// تم التطوير بواسطة كيرو

import {
  EmbedBuilder,
  ColorResolvable,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from "discord.js";
import { Ticket, TicketPanel } from "../database/schema";
import { TICKET_TYPES } from "./constants";

export function hexToNumber(hex: string): number {
  return parseInt(hex.replace("#", ""), 16);
}

export function getStatusColor(status: string): number {
  const colors: Record<string, number> = {
    open: 0x57f287,
    in_progress: 0xfee75c,
    pending_approval: 0xffa500,
    closed: 0xed4245,
  };
  return colors[status] ?? 0x5865f2;
}

export function getStatusText(status: string): string {
  const texts: Record<string, string> = {
    open: "🟢 مفتوح",
    in_progress: "🟡 قيد التنفيذ",
    pending_approval: "🟠 بانتظار الموافقة",
    closed: "🔴 مغلق",
  };
  return texts[status] ?? status;
}

export function getPriorityColor(priority: string): number {
  const colors: Record<string, number> = {
    high: 0xed4245,
    medium: 0xfee75c,
    low: 0x57f287,
  };
  return colors[priority] ?? 0x5865f2;
}

export function getPriorityText(priority: string): string {
  const texts: Record<string, string> = {
    high: "🔴 عالي",
    medium: "🟡 متوسط",
    low: "🟢 منخفض",
  };
  return texts[priority] ?? priority;
}

export function buildTicketEmbed(
  ticket: Ticket,
  userName: string,
  userAvatar: string | null
): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(getStatusColor(ticket.status) as ColorResolvable)
    .setTitle(`🎫 تكت #${ticket.ticketNumber}`)
    .setDescription(
      `مرحباً <@${ticket.userId}>! تم فتح تكتك بنجاح.\nسيتم الرد عليك في أقرب وقت ممكن.`
    )
    .addFields(
      { name: "👤 صاحب التكت", value: `<@${ticket.userId}>`, inline: true },
      { name: "📊 الحالة", value: getStatusText(ticket.status), inline: true },
      { name: "⚡ الأولوية", value: getPriorityText(ticket.priority), inline: true },
      { name: "📁 النوع", value: ticket.ticketType || "غير محدد", inline: true },
      {
        name: "🤖 الوسيط المعيّن",
        value: ticket.assignedTo ? `<@${ticket.assignedTo}>` : "غير معيّن",
        inline: true,
      },
      {
        name: "📌 مُستلَم من قِبل",
        value: ticket.claimedBy ? `<@${ticket.claimedBy}>` : "لم يُستلم بعد",
        inline: true,
      }
    )
    .setFooter({ text: `معرف التكت: ${ticket.id}`, iconURL: userAvatar || undefined })
    .setTimestamp();

  return embed;
}

export function buildTicketButtons(ticket: Ticket): ActionRowBuilder<ButtonBuilder> {
  const claimBtn = new ButtonBuilder()
    .setCustomId(`ticket_claim_${ticket.id}`)
    .setLabel("استلام التكت")
    .setStyle(ButtonStyle.Primary)
    .setEmoji("🔵")
    .setDisabled(!!ticket.claimedBy);

  const unclaimBtn = new ButtonBuilder()
    .setCustomId(`ticket_unclaim_${ticket.id}`)
    .setLabel("فك الاستلام")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("🟡")
    .setDisabled(!ticket.claimedBy);

  const closeBtn = new ButtonBuilder()
    .setCustomId(`ticket_close_${ticket.id}`)
    .setLabel("إغلاق التكت")
    .setStyle(ButtonStyle.Danger)
    .setEmoji("🔴");

  return new ActionRowBuilder<ButtonBuilder>().addComponents(claimBtn, unclaimBtn, closeBtn);
}

export function buildPanelEmbed(panel: TicketPanel): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(hexToNumber(panel.color) as ColorResolvable)
    .setTitle(panel.title)
    .setDescription(panel.description);

  if (panel.imageUrl) embed.setThumbnail(panel.imageUrl);
  if (panel.footerText) embed.setFooter({ text: panel.footerText });

  embed.setTimestamp();
  return embed;
}

export function buildPanelButton(panel: TicketPanel): ActionRowBuilder<ButtonBuilder> {
  const btn = new ButtonBuilder()
    .setCustomId(`panel_open_${panel.id}`)
    .setLabel(panel.buttonLabel)
    .setStyle(ButtonStyle.Success);

  return new ActionRowBuilder<ButtonBuilder>().addComponents(btn);
}

export function buildTechPanelEmbed(panel: TicketPanel): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(hexToNumber(panel.color) as ColorResolvable)
    .setTitle(panel.title)
    .setDescription(panel.description);

  if (panel.imageUrl) embed.setThumbnail(panel.imageUrl);
  if (panel.footerText) embed.setFooter({ text: panel.footerText });

  embed.setTimestamp();
  return embed;
}

export function buildTechPanelButton(panel: TicketPanel): ActionRowBuilder<ButtonBuilder> {
  const btn = new ButtonBuilder()
    .setCustomId(`techpanel_open_${panel.id}`)
    .setLabel(panel.buttonLabel)
    .setStyle(ButtonStyle.Primary);

  return new ActionRowBuilder<ButtonBuilder>().addComponents(btn);
}

export function buildTicketTypeMenu(panelId: number): ActionRowBuilder<StringSelectMenuBuilder> {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`ticket_type_${panelId}`)
    .setPlaceholder("🎯 اختر نوع التكت")
    .setMinValues(1)
    .setMaxValues(1);

  for (const type of TICKET_TYPES) {
    menu.addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel(`${type.emoji} ${type.label}`)
        .setValue(type.key)
    );
  }

  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
}

export function buildPriorityMenu(ticketId: number): ActionRowBuilder<StringSelectMenuBuilder> {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`ticket_priority_${ticketId}`)
    .setPlaceholder("⚡ تحديد الأولوية")
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel("🔴 عالي").setValue("high"),
      new StringSelectMenuOptionBuilder().setLabel("🟡 متوسط").setValue("medium"),
      new StringSelectMenuOptionBuilder().setLabel("🟢 منخفض").setValue("low")
    );

  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
}

export function buildRatingButtons(ticketId: number): ActionRowBuilder<ButtonBuilder> {
  const row = new ActionRowBuilder<ButtonBuilder>();

  for (let i = 1; i <= 5; i++) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`rating_${ticketId}_${i}`)
        .setLabel(`${"⭐".repeat(i)}`)
        .setStyle(ButtonStyle.Secondary)
    );
  }

  return row;
}

export function buildRatingEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xfee75c as ColorResolvable)
    .setTitle("⭐ تقييم الدعم")
    .setDescription(
      "نشكرك على تواصلك معنا!\nيرجى تقييم تجربتك مع فريق الدعم من خلال الأزرار أدناه."
    )
    .setTimestamp();
}

export function buildDashboardEmbed(data: {
  openTickets: number;
  closedTickets: number;
  totalTickets: number;
  topMods: Array<{ userId: string; count: number }>;
  avgRating: number;
}): EmbedBuilder {
  const topModsText =
    data.topMods.length > 0
      ? data.topMods
          .map((m, i) => `${["🥇", "🥈", "🥉"][i] || "🏅"} <@${m.userId}> — ${m.count} تكت`)
          .join("\n")
      : "لا توجد بيانات بعد";

  return new EmbedBuilder()
    .setColor(0x5865f2 as ColorResolvable)
    .setTitle("📊 لوحة التحكم — إحصائيات التكتات")
    .addFields(
      { name: "🟢 تكتات مفتوحة", value: `${data.openTickets}`, inline: true },
      { name: "🔴 تكتات مغلقة", value: `${data.closedTickets}`, inline: true },
      { name: "📦 إجمالي التكتات", value: `${data.totalTickets}`, inline: true },
      { name: "⭐ متوسط التقييم", value: `${data.avgRating.toFixed(1)} / 5.0`, inline: true },
      { name: "🏆 أفضل الوسطاء", value: topModsText }
    )
    .setFooter({ text: "تحديث لحظي" })
    .setTimestamp();
}

export function buildErrorEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xed4245 as ColorResolvable)
    .setTitle("❌ خطأ")
    .setDescription(message)
    .setTimestamp();
}

export function buildSuccessEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x57f287 as ColorResolvable)
    .setTitle("✅ نجح")
    .setDescription(message)
    .setTimestamp();
}
