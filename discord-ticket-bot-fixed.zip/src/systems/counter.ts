import { db, modStats } from "../database";
import { eq, and, desc } from "drizzle-orm";

// ============================================================
// نظام عداد التكتات للوسطاء
// ============================================================

/**
 * زيادة عداد الوسيط عند إغلاق/معالجة تكت
 */
export async function incrementModCount(userId: string, guildId: string): Promise<void> {
  const now = new Date();

  const record = await db.query.modStats.findFirst({
    where: and(eq(modStats.userId, userId), eq(modStats.guildId, guildId)),
  });

  if (!record) {
    await db.insert(modStats).values({
      userId,
      guildId,
      dailyCount: 1,
      weeklyCount: 1,
      totalCount: 1,
      lastDailyReset: now,
      lastWeeklyReset: now,
    });
    return;
  }

  // التحقق من حاجة الإصفار
  const needsDailyReset = isMoreThan24Hours(record.lastDailyReset!);
  const needsWeeklyReset = isMoreThan7Days(record.lastWeeklyReset!);

  await db
    .update(modStats)
    .set({
      dailyCount: needsDailyReset ? 1 : record.dailyCount + 1,
      weeklyCount: needsWeeklyReset ? 1 : record.weeklyCount + 1,
      totalCount: record.totalCount + 1,
      lastDailyReset: needsDailyReset ? now : record.lastDailyReset,
      lastWeeklyReset: needsWeeklyReset ? now : record.lastWeeklyReset,
      updatedAt: now,
    })
    .where(eq(modStats.id, record.id));
}

/**
 * الحصول على إحصائيات وسيط
 */
export async function getModStats(
  userId: string,
  guildId: string
): Promise<{ daily: number; weekly: number; total: number }> {
  const record = await db.query.modStats.findFirst({
    where: and(eq(modStats.userId, userId), eq(modStats.guildId, guildId)),
  });

  if (!record) return { daily: 0, weekly: 0, total: 0 };

  // التحقق من صلاحية العدادات
  const daily = isMoreThan24Hours(record.lastDailyReset!) ? 0 : record.dailyCount;
  const weekly = isMoreThan7Days(record.lastWeeklyReset!) ? 0 : record.weeklyCount;

  return { daily, weekly, total: record.totalCount };
}

/**
 * الحصول على أفضل الوسطاء (Leaderboard)
 */
export async function getTopMods(
  guildId: string,
  limit = 5
): Promise<Array<{ userId: string; count: number }>> {
  const records = await db.query.modStats.findMany({
    where: eq(modStats.guildId, guildId),
    orderBy: [desc(modStats.totalCount)],
    limit,
  });

  return records.map((r) => ({ userId: r.userId, count: r.totalCount }));
}

/**
 * إصفار العدادات (يستطيع تنفيذها الأونر فقط)
 */
export async function resetModStats(guildId: string): Promise<void> {
  const now = new Date();
  await db
    .update(modStats)
    .set({
      dailyCount: 0,
      weeklyCount: 0,
      totalCount: 0,
      lastDailyReset: now,
      lastWeeklyReset: now,
    })
    .where(eq(modStats.guildId, guildId));
}

// ============================================================
// مساعدات الوقت
// ============================================================
function isMoreThan24Hours(date: Date): boolean {
  return Date.now() - date.getTime() > 24 * 60 * 60 * 1000;
}

function isMoreThan7Days(date: Date): boolean {
  return Date.now() - date.getTime() > 7 * 24 * 60 * 60 * 1000;
}
