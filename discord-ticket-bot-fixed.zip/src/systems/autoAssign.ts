import { Guild } from "discord.js";
import { db, modStats, serverSettings } from "../database";
import { eq, asc } from "drizzle-orm";

// ============================================================
// نظام التوزيع التلقائي للوسطاء (Round-robin / أقل عدد تكتات)
// ============================================================

// تتبع Round-robin
const roundRobinIndex = new Map<string, number>();

/**
 * الحصول على الوسيط الأنسب لتعيينه (أقل عدد تكتات)
 */
export async function autoAssignMod(guild: Guild): Promise<string | null> {
  const settings = await db.query.serverSettings.findFirst({
    where: eq(serverSettings.guildId, guild.id),
  });

  // الحصول على أعضاء أدوار الدعم
  const supportRoleIds = settings?.supportRoleIds ?? [];
  if (supportRoleIds.length === 0) return null;

  // جمع كل أعضاء أدوار الدعم
  const supportMembers: string[] = [];
  for (const roleId of supportRoleIds) {
    const role = guild.roles.cache.get(roleId);
    if (!role) continue;
    for (const [memberId, member] of role.members) {
      if (!member.user.bot && !supportMembers.includes(memberId)) {
        supportMembers.push(memberId);
      }
    }
  }

  if (supportMembers.length === 0) return null;

  // الحصول على إحصائيات الوسطاء
  const stats = await db.query.modStats.findMany({
    where: eq(modStats.guildId, guild.id),
    orderBy: [asc(modStats.dailyCount)],
  });

  const statsMap = new Map(stats.map((s) => [s.userId, s.dailyCount]));

  // ترتيب الوسطاء حسب أقل عدد تكتات يومي
  const sorted = supportMembers.sort((a, b) => {
    const countA = statsMap.get(a) ?? 0;
    const countB = statsMap.get(b) ?? 0;
    return countA - countB;
  });

  return sorted[0] ?? null;
}

/**
 * توزيع Round-robin بسيط
 */
export function roundRobinAssign(guildId: string, candidates: string[]): string | null {
  if (candidates.length === 0) return null;

  const current = roundRobinIndex.get(guildId) ?? 0;
  const selected = candidates[current % candidates.length];
  roundRobinIndex.set(guildId, current + 1);

  return selected ?? null;
}
