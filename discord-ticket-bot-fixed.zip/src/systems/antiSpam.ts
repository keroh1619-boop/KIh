import { db, antiSpam } from "../database";
import { eq, and } from "drizzle-orm";
import { config } from "../config";

// ============================================================
// نظام Anti-Spam (منع إنشاء تكتات متكررة بسرعة)
// ============================================================

/**
 * التحقق من Anti-Spam قبل إنشاء تكت
 * @returns رسالة الخطأ أو null إذا مسموح
 */
export async function checkAntiSpam(userId: string, guildId: string): Promise<string | null> {
  const now = new Date();

  const record = await db.query.antiSpam.findFirst({
    where: and(eq(antiSpam.userId, userId), eq(antiSpam.guildId, guildId)),
  });

  if (record) {
    const lastTime = record.lastTicketAt!.getTime();
    const elapsed = (now.getTime() - lastTime) / 1000;

    if (elapsed < config.ticket.cooldownSeconds) {
      const remaining = Math.ceil(config.ticket.cooldownSeconds - elapsed);
      return `⏱️ يرجى الانتظار **${remaining}** ثانية قبل فتح تكت جديد.`;
    }

    // تحديث وقت آخر تكت
    await db
      .update(antiSpam)
      .set({ lastTicketAt: now, attemptCount: 0 })
      .where(eq(antiSpam.id, record.id));
  } else {
    // إنشاء سجل جديد
    await db.insert(antiSpam).values({ userId, guildId, lastTicketAt: now, attemptCount: 0 });
  }

  return null;
}

/**
 * تسجيل محاولة سبام (عند الرفض)
 */
export async function recordSpamAttempt(userId: string, guildId: string): Promise<void> {
  const record = await db.query.antiSpam.findFirst({
    where: and(eq(antiSpam.userId, userId), eq(antiSpam.guildId, guildId)),
  });

  if (record) {
    await db
      .update(antiSpam)
      .set({ attemptCount: record.attemptCount + 1 })
      .where(eq(antiSpam.id, record.id));
  }
}
