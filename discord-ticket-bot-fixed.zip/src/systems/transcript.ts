import { Client, TextChannel, AttachmentBuilder } from "discord.js";
import { db, tickets, transcripts, serverSettings } from "../database";
import { eq } from "drizzle-orm";
import { Ticket } from "../database/schema";

// ============================================================
// نظام Transcript — حفظ وتصدير المحادثات
// ============================================================

/**
 * توليد Transcript بصيغة HTML
 */
export async function generateHtmlTranscript(
  client: Client,
  ticket: Ticket,
  channel: TextChannel
): Promise<string> {
  const messages = await channel.messages.fetch({ limit: 100 });
  const sortedMessages = [...messages.values()].reverse();

  const messagesHtml = sortedMessages
    .map((msg) => {
      const time = msg.createdAt.toLocaleString("ar-SA");
      const avatar = msg.author.displayAvatarURL({ size: 64 });
      const content = escapeHtml(msg.content || "");
      const attachmentsHtml = msg.attachments
        .map((a) =>
          a.contentType?.startsWith("image/")
            ? `<img src="${a.url}" alt="صورة" style="max-width:300px;border-radius:8px;margin-top:4px;">`
            : `<a href="${a.url}" target="_blank" style="color:#00b0f4">📎 ${a.name}</a>`
        )
        .join("<br>");

      return `
      <div class="message">
        <img class="avatar" src="${avatar}" alt="avatar">
        <div class="content">
          <span class="username">${escapeHtml(msg.author.username)}</span>
          <span class="time">${time}</span>
          <div class="text">${content}</div>
          ${attachmentsHtml}
        </div>
      </div>`;
    })
    .join("");

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Transcript — تكت #${ticket.ticketNumber}</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; padding: 20px; background: #313338; color: #dbdee1; font-family: 'Segoe UI', sans-serif; }
    .header { background: #2b2d31; border-radius: 12px; padding: 20px; margin-bottom: 20px; border-left: 4px solid #5865f2; }
    .header h1 { color: #fff; margin: 0 0 8px; font-size: 1.5rem; }
    .header p { margin: 4px 0; color: #b5bac1; font-size: 0.9rem; }
    .messages { display: flex; flex-direction: column; gap: 8px; }
    .message { display: flex; gap: 12px; padding: 10px 14px; border-radius: 8px; transition: background 0.2s; }
    .message:hover { background: #2b2d31; }
    .avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; }
    .content { flex: 1; }
    .username { color: #c9cdfb; font-weight: 600; margin-left: 8px; }
    .time { color: #87878e; font-size: 0.75rem; }
    .text { margin-top: 4px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; }
    .footer { margin-top: 24px; text-align: center; color: #87878e; font-size: 0.8rem; padding: 16px; border-top: 1px solid #3f4147; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; margin: 2px; }
    .badge-open { background: #57f287; color: #000; }
    .badge-closed { background: #ed4245; color: #fff; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🎫 Transcript — تكت #${ticket.ticketNumber}</h1>
    <p>👤 صاحب التكت: <strong>${ticket.userId}</strong></p>
    <p>📊 الحالة: <span class="badge badge-closed">مغلق</span></p>
    <p>📅 تاريخ الفتح: ${ticket.createdAt?.toLocaleString("ar-SA")}</p>
    <p>📅 تاريخ الإغلاق: ${ticket.closedAt?.toLocaleString("ar-SA") || "—"}</p>
    <p>💬 عدد الرسائل: ${sortedMessages.length}</p>
  </div>
  <div class="messages">
    ${messagesHtml}
  </div>
  <div class="footer">
    تم توليد هذا الـ Transcript تلقائياً بواسطة نظام التكتات
  </div>
</body>
</html>`;
}

/**
 * توليد Transcript بصيغة TXT
 */
export async function generateTxtTranscript(
  ticket: Ticket,
  channel: TextChannel
): Promise<string> {
  const messages = await channel.messages.fetch({ limit: 100 });
  const sortedMessages = [...messages.values()].reverse();

  const header = [
    "=".repeat(60),
    `TRANSCRIPT — تكت #${ticket.ticketNumber}`,
    "=".repeat(60),
    `صاحب التكت: ${ticket.userId}`,
    `تاريخ الفتح: ${ticket.createdAt?.toLocaleString("ar-SA")}`,
    `تاريخ الإغلاق: ${ticket.closedAt?.toLocaleString("ar-SA") || "—"}`,
    `عدد الرسائل: ${sortedMessages.length}`,
    "=".repeat(60),
    "",
  ].join("\n");

  const body = sortedMessages
    .map((msg) => {
      const time = msg.createdAt.toLocaleString("ar-SA");
      const attachments = msg.attachments.map((a) => `[مرفق: ${a.url}]`).join(" ");
      return `[${time}] ${msg.author.username}: ${msg.content || ""}${attachments ? " " + attachments : ""}`;
    })
    .join("\n");

  return header + body;
}

/**
 * إرسال Transcript إلى روم اللوج
 */
export async function sendTranscript(
  client: Client,
  ticket: Ticket,
  channel: TextChannel
): Promise<void> {
  try {
    const settings = await db.query.serverSettings.findFirst({
      where: eq(serverSettings.guildId, ticket.guildId),
    });

    const targetChannelId = settings?.transcriptChannelId || settings?.logChannelId;
    if (!targetChannelId) return;

    const targetChannel = client.channels.cache.get(targetChannelId) as TextChannel;
    if (!targetChannel) return;

    // توليد كلا الصيغتين
    const htmlContent = await generateHtmlTranscript(client, ticket, channel);
    const txtContent = await generateTxtTranscript(ticket, channel);

    // حفظ في قاعدة البيانات
    await db.insert(transcripts).values({
      ticketId: ticket.id,
      guildId: ticket.guildId,
      content: htmlContent,
      format: "html",
    });

    // إرسال كملفات مرفقة
    const htmlBuffer = Buffer.from(htmlContent, "utf-8");
    const txtBuffer = Buffer.from(txtContent, "utf-8");

    const htmlAttachment = new AttachmentBuilder(htmlBuffer, {
      name: `transcript-ticket-${ticket.ticketNumber}.html`,
    });
    const txtAttachment = new AttachmentBuilder(txtBuffer, {
      name: `transcript-ticket-${ticket.ticketNumber}.txt`,
    });

    await targetChannel.send({
      content: `📁 **Transcript | تكت #${ticket.ticketNumber}**\nصاحب التكت: <@${ticket.userId}>`,
      files: [htmlAttachment, txtAttachment],
    });
  } catch (error) {
    console.error("خطأ في إرسال Transcript:", error);
  }
}

// مساعد HTML Escape
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
