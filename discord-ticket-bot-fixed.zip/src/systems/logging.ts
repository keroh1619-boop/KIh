// تم التطوير بواسطة كيرو

import { Client, EmbedBuilder, TextChannel, ColorResolvable } from "discord.js";
  import { db, eventLogs, serverSettings } from "../database";
  import { eq } from "drizzle-orm";

  export type LogEvent =
    | "ticket_open" | "ticket_close" | "ticket_claim" | "ticket_unclaim"
    | "ticket_assign" | "ticket_rate" | "panel_create" | "mod_reset"
    | "approval_request" | "approval_accept" | "approval_reject"
    | "done_request" | "done_approve" | "done_reject"
    | "bulk_close";

  const eventColors: Record<LogEvent, number> = {
    ticket_open: 0x57f287, ticket_close: 0xed4245, ticket_claim: 0x5865f2,
    ticket_unclaim: 0xfee75c, ticket_assign: 0xeb459e, ticket_rate: 0xff9f43,
    panel_create: 0x00b4d8, mod_reset: 0x95a5a6,
    approval_request: 0xffa500, approval_accept: 0x57f287, approval_reject: 0xed4245,
    done_request: 0xffa500, done_approve: 0x57f287, done_reject: 0xed4245,
    bulk_close: 0xed4245,
  };

  const eventTitles: Record<LogEvent, string> = {
    ticket_open: "🟢 تكت جديد", ticket_close: "🔴 إغلاق تكت", ticket_claim: "🔵 استلام تكت",
    ticket_unclaim: "🟡 فك استلام", ticket_assign: "🤖 تعيين وسيط", ticket_rate: "⭐ تقييم",
    panel_create: "📋 بانل جديد", mod_reset: "🔄 إصفار الإحصائيات",
    approval_request: "📨 طلب إذن وساطة", approval_accept: "✅ قبول وساطة", approval_reject: "❌ رفض وساطة",
    done_request: "👍 طلب موافقة تم", done_approve: "✅ موافقة على تم", done_reject: "❌ رفض تم",
    bulk_close: "🗑️ إغلاق جماعي للتكتات",
  };

  export async function sendLog(
    client: Client, guildId: string, event: LogEvent,
    fields: Array<{ name: string; value: string; inline?: boolean }>,
    ticketId?: number, actorId?: string, targetId?: string,
    details?: Record<string, unknown>
  ): Promise<void> {
    try {
      await db.insert(eventLogs).values({ guildId, ticketId, eventType: event, actorId, targetId, details: details || {} });
      const settings = await db.query.serverSettings.findFirst({ where: eq(serverSettings.guildId, guildId) });
      if (!settings?.logChannelId) return;
      const channel = client.channels.cache.get(settings.logChannelId) as TextChannel;
      if (!channel) return;
      const embed = new EmbedBuilder()
        .setColor(eventColors[event] as ColorResolvable).setTitle(eventTitles[event])
        .addFields(fields).setTimestamp().setFooter({ text: "نظام اللوج التلقائي" });
      await channel.send({ embeds: [embed] });
    } catch (error) { console.error("خطأ في نظام اللوج:", error); }
  }
