import { db, points } from "../database";
import { eq, and, desc } from "drizzle-orm";
import { config } from "../config";

// ============================================================
// نظام النقاط والليدربورد
// ============================================================

/**
 * إضافة نقاط لوسيط
 */
export async function addPoints(userId: string, guildId: string, amount: number): Promise<number> {
  const now = new Date();

  const record = await db.query.points.findFirst({
    where: and(eq(points.userId, userId), eq(points.guildId, guildId)),
  });

  if (!record) {
    await db.insert(points).values({
      userId,
      guildId,
      totalPoints: amount,
      updatedAt: now,
    });
    return amount;
  }

  const newTotal = record.totalPoints + amount;
  await db
    .update(points)
    .set({ totalPoints: newTotal, updatedAt: now })
    .where(eq(points.id, record.id));

  return newTotal;
}

/**
 * الحصول على نقاط مستخدم
 */
export async function getUserPoints(userId: string, guildId: string): Promise<number> {
  const record = await db.query.points.findFirst({
    where: and(eq(points.userId, userId), eq(points.guildId, guildId)),
  });
  return record?.totalPoints ?? 0;
}

/**
 * الحصول على قائمة الصدارة (Leaderboard)
 */
export async function getLeaderboard(
  guildId: string,
  limit = 10
): Promise<Array<{ userId: string; totalPoints: number; rank: number }>> {
  const records = await db.query.points.findMany({
    where: eq(points.guildId, guildId),
    orderBy: [desc(points.totalPoints)],
    limit,
  });

  return records.map((r, i) => ({
    userId: r.userId,
    totalPoints: r.totalPoints,
    rank: i + 1,
  }));
}

/**
 * إصفار نقاط السيرفر
 */
export async function resetPoints(guildId: string): Promise<void> {
  await db
    .update(points)
    .set({ totalPoints: 0, updatedAt: new Date() })
    .where(eq(points.guildId, guildId));
}

/**
 * منح نقاط عند إغلاق تكت
 */
export async function awardTicketPoints(userId: string, guildId: string): Promise<number> {
  return addPoints(userId, guildId, config.ticket.pointsPerClose);
}
