// تم التطوير بواسطة كيرو

import {
  ChatInputCommandInteraction,
  ModalSubmitInteraction,
  ButtonInteraction,
  TextChannel,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
} from "discord.js";
import { db, ticketPanels } from "../database";
import { eq } from "drizzle-orm";
import { buildPanelEmbed, buildPanelButton, buildErrorEmbed, buildSuccessEmbed, buildTechPanelEmbed, buildTechPanelButton } from "../utils/embeds";
import { TicketPanel } from "../database/schema";

interface PanelDraft {
  guildId: string;
  channelId: string;
  panelType: string;
  title: string;
  description: string;
  color: string;
  buttonLabel: string;
  imageUrl?: string;
  thumbnailUrl?: string;
  footerText?: string;
  createdBy: string;
}

const panelDrafts = new Map<string, PanelDraft>();

export async function startPanelCreation(
  interaction: ChatInputCommandInteraction,
  targetChannelId: string,
  panelType: string = "mediator"
): Promise<void> {
  const draftKey = `${interaction.user.id}_${panelType}`;
  panelDrafts.set(draftKey, {
    guildId: interaction.guildId!,
    channelId: targetChannelId,
    panelType,
    title: "",
    description: "",
    color: "#5865F2",
    buttonLabel: panelType === "tech_support" ? "🔧 فتح تكت دعم فني" : "📩 فتح تكت",
    createdBy: interaction.user.id,
  });

  const modal = new ModalBuilder()
    .setCustomId(`panel_create_modal_${panelType}`)
    .setTitle(panelType === "tech_support" ? "🔧 إنشاء بانل دعم فني" : "🎫 إنشاء بانل تكت");

  const titleInput = new TextInputBuilder()
    .setCustomId("panel_title")
    .setLabel("عنوان البانل")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(panelType === "tech_support" ? "مثال: 🔧 دعم فني" : "مثال: 🎫 فتح تكت دعم")
    .setRequired(true)
    .setMaxLength(256);

  const colorInput = new TextInputBuilder()
    .setCustomId("panel_color")
    .setLabel("لون الإيمبد (HEX)")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("مثال: #5865F2")
    .setRequired(false)
    .setMaxLength(7);

  const buttonLabelInput = new TextInputBuilder()
    .setCustomId("panel_button_label")
    .setLabel("نص زر فتح التكت")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(panelType === "tech_support" ? "مثال: 🔧 فتح تكت دعم فني" : "مثال: 📩 فتح تكت")
    .setRequired(false)
    .setMaxLength(80);

  const imageInput = new TextInputBuilder()
    .setCustomId("panel_image")
    .setLabel("رابط صورة البانل (اختياري)")
    .setStyle(TextInputStyle.Short)
    .setPlaceholder("https://example.com/image.png")
    .setRequired(false)
    .setMaxLength(500);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(titleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(colorInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(buttonLabelInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(imageInput)
  );

  await interaction.showModal(modal);
}

export async function handlePanelModal(
  interaction: ModalSubmitInteraction,
  panelType: string = "mediator"
): Promise<void> {
  const title = interaction.fields.getTextInputValue("panel_title");
  const colorRaw = interaction.fields.getTextInputValue("panel_color");
  const buttonLabel = interaction.fields.getTextInputValue("panel_button_label");
  const imageRaw = interaction.fields.getTextInputValue("panel_image");

  const color: string =
    colorRaw && /^#[0-9A-Fa-f]{6}$/.test(colorRaw) ? colorRaw : "#5865F2";

  const imageUrl = imageRaw && /^https?:\/\//i.test(imageRaw) ? imageRaw : undefined;

  const defaultDesc = panelType === "tech_support"
    ? "اضغط على الزر أدناه لفتح تكت دعم فني وسيتم الرد عليك."
    : "اضغط على الزر أدناه لفتح تكت دعم وسيتم الرد عليك.";

  const draftKey = `${interaction.user.id}_${panelType}`;
  const existingDraft = panelDrafts.get(draftKey);

  const draft: PanelDraft = {
    guildId: interaction.guildId!,
    channelId: existingDraft?.channelId || interaction.channelId!,
    panelType,
    title,
    description: defaultDesc,
    color,
    buttonLabel: buttonLabel || (panelType === "tech_support" ? "🔧 فتح تكت دعم فني" : "📩 فتح تكت"),
    imageUrl,
    createdBy: interaction.user.id,
  };

  panelDrafts.set(draftKey, draft);

  const guild = interaction.guild!;
  const targetChannel = guild.channels.cache.get(draft.channelId) as TextChannel;

  if (!targetChannel || targetChannel.type !== ChannelType.GuildText) {
    await interaction.reply({
      embeds: [buildErrorEmbed("❌ الروم غير صحيح.")],
      ephemeral: true,
    });
    return;
  }

  try {
    const panelData = draft as unknown as TicketPanel;

    const [savedPanel] = await db
      .insert(ticketPanels)
      .values({
        ...draft,
        messageId: "pending",
      })
      .returning();

    let embed, panelButton;
    if (panelType === "tech_support") {
      embed = buildTechPanelEmbed(savedPanel);
      panelButton = buildTechPanelButton(savedPanel);
    } else {
      embed = buildPanelEmbed(savedPanel);
      panelButton = buildPanelButton(savedPanel);
    }

    const sentMsg = await targetChannel.send({ embeds: [embed], components: [panelButton] });

    await db
      .update(ticketPanels)
      .set({ messageId: sentMsg.id })
      .where(eq(ticketPanels.id, savedPanel.id));

    panelDrafts.delete(draftKey);

    await interaction.reply({
      content: `✅ تم نشر البانل في <#${targetChannel.id}> بنجاح!`,
      ephemeral: true,
    });
  } catch (error) {
    console.error("خطأ في نشر البانل:", error);
    await interaction.reply({
      embeds: [buildErrorEmbed("❌ حدث خطأ أثناء نشر البانل.")],
      ephemeral: true,
    });
  }
}

export async function cancelPanel(interaction: ButtonInteraction): Promise<void> {
  panelDrafts.delete(interaction.user.id);
  panelDrafts.delete(`${interaction.user.id}_mediator`);
  panelDrafts.delete(`${interaction.user.id}_tech_support`);
  await interaction.update({
    content: "❌ تم إلغاء إنشاء البانل.",
    embeds: [],
    components: [],
  });
}

export async function getPanelById(panelId: number): Promise<TicketPanel | undefined> {
  return db.query.ticketPanels.findFirst({
    where: eq(ticketPanels.id, panelId),
  });
}
