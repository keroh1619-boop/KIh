import OpenAI from "openai";
import { config } from "../config";

// ============================================================
// نظام AI داخل التكت — ردود تلقائية ذكية
// ============================================================

let openai: OpenAI | null = null;

function getOpenAI(): OpenAI {
  if (!openai) {
    openai = new OpenAI({
      apiKey: config.openaiApiKey || "placeholder",
      baseURL: config.openaiBaseUrl,
    });
  }
  return openai;
}

const systemPrompt = `أنت مساعد دعم ذكي في بوت تكتات لسيرفر ديسكورد. مهمتك مساعدة المستخدمين بالإجابة على استفساراتهم الشائعة وتوجيههم.
قواعد مهمة:
- الرد دائماً باللغة العربية
- الإجابات مختصرة وواضحة (2-4 أسطر كحد أقصى)
- إذا لم تعرف الإجابة، قل للمستخدم أن يانتظر الوسيط المختص
- لا تتعدى صلاحياتك أو تقدم معلومات حساسة
- كن ودوداً ومحترفاً دائماً`;

/**
 * الحصول على رد AI لرسالة مستخدم
 */
export async function getAIResponse(
  userMessage: string,
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }> = []
): Promise<string | null> {
  if (!config.openaiApiKey) {
    return null; // AI غير مفعّل
  }

  try {
    const client = getOpenAI();

    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: "system", content: systemPrompt },
      ...conversationHistory.slice(-6), // آخر 6 رسائل للسياق
      { role: "user", content: userMessage },
    ];

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      max_tokens: 300,
      temperature: 0.7,
    });

    return response.choices[0]?.message?.content ?? null;
  } catch (error) {
    console.error("خطأ في نظام AI:", error);
    return null;
  }
}

/**
 * التحقق من أن الرسالة تستحق رداً من AI
 */
export function shouldAIRespond(content: string): boolean {
  // تجاهل الرسائل القصيرة جداً أو التي تبدأ بـ !
  if (content.length < 5 || content.startsWith("!") || content.startsWith("/")) return false;

  // الكلمات المفتاحية التي تستدعي رد AI
  const keywords = [
    "كيف", "ماذا", "ما هو", "ما هي", "هل", "لماذا", "متى", "أين",
    "how", "what", "why", "when", "where", "help", "مشكلة", "لا يعمل", "خطأ",
    "استفسار", "سؤال", "أحتاج", "ممكن", "أريد",
  ];

  return keywords.some((kw) => content.toLowerCase().includes(kw.toLowerCase()));
}
