// تم التطوير بواسطة كيرو

import {
    ButtonInteraction, GuildMember, TextChannel, PermissionFlagsBits,
  } from "discord.js";
  import { db, tickets } from "../database";
  import { eq } from "drizzle-orm";
  import { isModerator, isHighAdmin } from "../utils/permissions";
  import { buildTicketEmbed, buildTicketButtons, buildPriorityMenu, buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
  import { sendLog } from "./logging";
  import { Ticket } from "../database/schema";

  export async function claimTicket(interaction: ButtonInteraction, ticket: Ticket): Promise<void> {
    const member = interaction.member as GuildMember;
    const highAdmin = await isHighAdmin(member);

    if (!highAdmin && !(await isModerator(member))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لا تملك صلاحية استلام التكتات.")], ephemeral: true });
      return;
    }
    if (ticket.claimedBy) {
      if (!highAdmin) {
        await interaction.reply({ embeds: [buildErrorEmbed(`❌ التكت مستلم بالفعل من قِبل <@${ticket.claimedBy}>.`)], ephemeral: true });
        return;
      }
    }
    const unclaimedBy = ticket.unclaimedBy ?? [];
    if (unclaimedBy.includes(interaction.user.id) && !highAdmin) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لا يمكنك استلام هذا التكت مجدداً بعد تخليك عنه.")], ephemeral: true });
      return;
    }
    const blockedMediators = ticket.blockedMediators ?? [];
    if (blockedMediators.includes(interaction.user.id) && !highAdmin) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لقد تم رفض طلب وساطتك في هذا التكت.")], ephemeral: true });
      return;
    }

    const [updated] = await db.update(tickets).set({
      claimedBy: interaction.user.id, status: "in_progress", updatedAt: new Date(),
    }).where(eq(tickets.id, ticket.id)).returning();

    const channel = interaction.channel as TextChannel;
    await channel.permissionOverwrites.edit(interaction.user.id, {
      SendMessages: true, ViewChannel: true, ReadMessageHistory: true, AttachFiles: true,
    });

    const user = await interaction.client.users.fetch(ticket.userId);
    const newEmbed = buildTicketEmbed(updated, user.username, user.displayAvatarURL());
    await interaction.update({ embeds: [newEmbed], components: [buildTicketButtons(updated), buildPriorityMenu(ticket.id)] });

    await channel.send({ embeds: [buildSuccessEmbed(`✅ تم استلام التكت من قِبل <@${interaction.user.id}>.`)] });

    await sendLog(interaction.client, ticket.guildId, "ticket_claim", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🔵 مُستلَم من", value: `<@${interaction.user.id}>`, inline: true },
      { name: "👤 صاحب التكت", value: `<@${ticket.userId}>`, inline: true },
    ], ticket.id, interaction.user.id, ticket.userId);
  }

  export async function unclaimTicket(interaction: ButtonInteraction, ticket: Ticket): Promise<void> {
    const member = interaction.member as GuildMember;
    const highAdmin = await isHighAdmin(member);

    if (!highAdmin && !(await isModerator(member))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط الوسطاء يمكنهم فك الاستلام.")], ephemeral: true });
      return;
    }
    if (ticket.claimedBy && ticket.claimedBy !== interaction.user.id && !highAdmin) {
      const { isOwner } = await import("../utils/permissions");
      if (!isOwner(interaction.user.id)) {
        await interaction.reply({ embeds: [buildErrorEmbed("❌ لا يمكنك فك استلام تكت قام باستلامه وسيط آخر.")], ephemeral: true });
        return;
      }
    }
    const unclaimedBy = [...(ticket.unclaimedBy ?? []), interaction.user.id];
    const [updated] = await db.update(tickets).set({
      claimedBy: null, status: "open", unclaimedBy, updatedAt: new Date(),
    }).where(eq(tickets.id, ticket.id)).returning();

    const channel = interaction.channel as TextChannel;
    try {
      await channel.permissionOverwrites.edit(interaction.user.id, {
        SendMessages: false, ViewChannel: true, ReadMessageHistory: true,
      });
    } catch {}

    const user = await interaction.client.users.fetch(ticket.userId);
    await interaction.update({ embeds: [buildTicketEmbed(updated, user.username, user.displayAvatarURL())], components: [buildTicketButtons(updated), buildPriorityMenu(ticket.id)] });
    await channel.send({ embeds: [buildErrorEmbed("🟡 تم فك استلام التكت. يمكن لأي وسيط آخر استلامه الآن.")] });

    await sendLog(interaction.client, ticket.guildId, "ticket_unclaim", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🟡 فك الاستلام بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id);
  }
