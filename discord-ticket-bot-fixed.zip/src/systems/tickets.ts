// تم التطوير بواسطة كيرو

import {
    ButtonInteraction, StringSelectMenuInteraction, ChatInputCommandInteraction,
    TextChannel, ChannelType, PermissionFlagsBits, OverwriteType, GuildMember, Client,
  } from "discord.js";
  import { db, tickets, serverSettings, ticketTypeSettings } from "../database";
  import { eq, and, count, ne } from "drizzle-orm";
  import {
    buildTicketEmbed, buildTicketButtons, buildPriorityMenu,
    buildErrorEmbed, buildRatingEmbed, buildRatingButtons,
  } from "../utils/embeds";
  import { getTicketTypeLabel, TECH_SUPPORT_TYPE_KEY } from "../utils/constants";
  import { checkAntiSpam } from "./antiSpam";
  import { autoAssignMod } from "./autoAssign";
  import { sendLog } from "./logging";
  import { sendTranscript } from "./transcript";
  import { incrementModCount } from "./counter";
  import { awardTicketPoints } from "./points";
  import { isModerator } from "../utils/permissions";
  import { Ticket } from "../database/schema";

  async function getNextTicketNumber(guildId: string): Promise<number> {
    const result = await db.select({ total: count(tickets.id) }).from(tickets).where(eq(tickets.guildId, guildId));
    return (Number(result[0]?.total) ?? 0) + 1;
  }

  export async function hasOpenTicket(userId: string, guildId: string): Promise<boolean> {
    const existing = await db.query.tickets.findFirst({
      where: and(eq(tickets.userId, userId), eq(tickets.guildId, guildId), eq(tickets.status, "open")),
    });
    if (!existing) {
      const inProgress = await db.query.tickets.findFirst({
        where: and(eq(tickets.userId, userId), eq(tickets.guildId, guildId), eq(tickets.status, "in_progress")),
      });
      if (!inProgress) {
        const pending = await db.query.tickets.findFirst({
          where: and(eq(tickets.userId, userId), eq(tickets.guildId, guildId), eq(tickets.status, "pending_approval")),
        });
        return !!pending;
      }
      return true;
    }
    return true;
  }

  function getCategoryForType(settings: any, ticketType?: string): string | undefined {
    if (!ticketType) return settings?.ticketCategoryId || undefined;

    if (ticketType === "mediator_defamation") {
      return settings?.defamationCategoryId || settings?.ticketCategoryId || undefined;
    }

    if (ticketType === TECH_SUPPORT_TYPE_KEY) {
      return settings?.techSupportCategoryId || settings?.ticketCategoryId || undefined;
    }

    return settings?.ticketCategoryId || undefined;
  }

  export async function createTicket(
    interaction: ButtonInteraction | StringSelectMenuInteraction,
    panelId: number, ticketType?: string
  ): Promise<void> {
    await interaction.deferReply({ ephemeral: true });
    const guild = interaction.guild!;
    const userId = interaction.user.id;

    if (await hasOpenTicket(userId, guild.id)) {
      await interaction.editReply({ embeds: [buildErrorEmbed("لديك تكت مفتوح بالفعل، يرجى إغلاقه أولاً.")] });
      return;
    }
    const spamError = await checkAntiSpam(userId, guild.id);
    if (spamError) { await interaction.editReply({ embeds: [buildErrorEmbed(spamError)] }); return; }

    const settings = await db.query.serverSettings.findFirst({ where: eq(serverSettings.guildId, guild.id) });

    let typeConfig: { mentionRoleId?: string | null; description?: string | null } = {};
    if (ticketType) {
      const tc = await db.query.ticketTypeSettings.findFirst({
        where: and(eq(ticketTypeSettings.guildId, guild.id), eq(ticketTypeSettings.typeKey, ticketType)),
      });
      if (tc) typeConfig = tc;
    }

    const ticketNumber = await getNextTicketNumber(guild.id);
    const channelName = `ticket-${ticketNumber}-${interaction.user.username.slice(0, 10).toLowerCase()}`;

    const categoryId = getCategoryForType(settings, ticketType);

    try {
      const permissionOverwrites: any[] = [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel], type: OverwriteType.Role },
        {
          id: userId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles],
          type: OverwriteType.Member,
        },
      ];

      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites,
      });

      if (settings?.supportRoleIds && settings.supportRoleIds.length > 0) {
        for (const roleId of settings.supportRoleIds) {
          await channel.permissionOverwrites.create(roleId, {
            ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
          });
        }
      }
      if (settings?.mediatorRoleId) {
        await channel.permissionOverwrites.create(settings.mediatorRoleId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
        });
      }

      if (settings?.highAdminRoleId) {
        await channel.permissionOverwrites.create(settings.highAdminRoleId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: true,
          ManageMessages: true, AttachFiles: true,
        });
      }

      if (settings?.permissionManagerRoleId) {
        await channel.permissionOverwrites.create(settings.permissionManagerRoleId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: true,
        });
      }

      const assignedMod = await autoAssignMod(guild);
      const [ticket] = await db.insert(tickets).values({
        ticketNumber, guildId: guild.id, channelId: channel.id, userId,
        assignedTo: assignedMod, status: "open", priority: "medium",
        ticketType: ticketType || null, unclaimedBy: [], blockedMediators: [],
      }).returning();

      const member = await guild.members.fetch(userId);
      const embed = buildTicketEmbed(ticket, member.user.username, member.user.displayAvatarURL());
      const buttons = buildTicketButtons(ticket);
      const priorityMenu = buildPriorityMenu(ticket.id);

      const mentionParts: string[] = [`<@${userId}>`];
      if (typeConfig.mentionRoleId) mentionParts.push(`<@&${typeConfig.mentionRoleId}>`);
      else if (assignedMod) mentionParts.push(`<@${assignedMod}>`);

      const descriptionMsg = typeConfig.description
        ? `\n\n📝 **${getTicketTypeLabel(ticketType!)}**\n${typeConfig.description}`
        : "";

      await channel.send({
        content: mentionParts.join(" ") + descriptionMsg,
        embeds: [embed], components: [buttons, priorityMenu],
      });

      await interaction.editReply({
        embeds: [{ color: 0x57f287, title: "✅ تم إنشاء تكتك بنجاح!", description: `تكتك موجود هنا: <#${channel.id}>` }],
      });

      await sendLog(interaction.client, guild.id, "ticket_open", [
        { name: "🎫 رقم التكت", value: `#${ticketNumber}`, inline: true },
        { name: "👤 المستخدم", value: `<@${userId}>`, inline: true },
        { name: "📁 النوع", value: ticketType ? getTicketTypeLabel(ticketType) : "غير محدد", inline: true },
        { name: "📝 الروم", value: `<#${channel.id}>`, inline: true },
        { name: "🤖 الوسيط المعيّن", value: assignedMod ? `<@${assignedMod}>` : "لا يوجد", inline: true },
      ], ticket.id, userId, undefined, { ticketNumber, channelId: channel.id });
    } catch (error) {
      console.error("خطأ في إنشاء التكت:", error);
      await interaction.editReply({ embeds: [buildErrorEmbed("❌ حدث خطأ أثناء إنشاء التكت.")] });
    }
  }

  export async function performClose(
    client: Client, channel: TextChannel, ticket: Ticket, closedById: string,
    skipPoints: boolean = false
  ): Promise<void> {
    const now = new Date();
    const [updated] = await db.update(tickets).set({
      status: "closed", closedBy: closedById, closedAt: now, updatedAt: now,
    }).where(eq(tickets.id, ticket.id)).returning();

    await sendTranscript(client, updated, channel);

    if (!skipPoints) {
      if (updated.claimedBy) {
        await incrementModCount(updated.claimedBy, ticket.guildId);
        await awardTicketPoints(updated.claimedBy, ticket.guildId);
      } else if (updated.assignedTo) {
        await incrementModCount(updated.assignedTo, ticket.guildId);
        await awardTicketPoints(updated.assignedTo, ticket.guildId);
      }
    }

    await sendLog(client, ticket.guildId, "ticket_close", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🔴 أُغلق بواسطة", value: `<@${closedById}>`, inline: true },
      { name: "👤 صاحب التكت", value: `<@${ticket.userId}>`, inline: true },
    ], ticket.id, closedById, ticket.userId);

    try {
      const user = await client.users.fetch(ticket.userId);
      await user.send({ embeds: [buildRatingEmbed()], components: [buildRatingButtons(ticket.id)] });
    } catch {}

    await channel.send({
      embeds: [{
        color: 0xed4245, title: "🔴 تم إغلاق التكت",
        description: `تم إغلاق التكت بواسطة <@${closedById}>.\nسيتم حذف هذا الروم خلال **10 ثوانٍ**.`,
        timestamp: now.toISOString(),
      }],
    });

    setTimeout(async () => { try { await channel.delete(); } catch {} }, 10000);
  }

  export async function closeTicket(interaction: ButtonInteraction, ticket: Ticket): Promise<void> {
    const member = interaction.member as GuildMember;
    if (!(await isModerator(member))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط الوسطاء يمكنهم إغلاق التكت.")], ephemeral: true });
      return;
    }
    await interaction.deferUpdate();
    await performClose(interaction.client, interaction.channel as TextChannel, ticket, interaction.user.id);
  }

  export async function updateTicketPriority(
    interaction: StringSelectMenuInteraction, ticket: Ticket, priority: string
  ): Promise<void> {
    const member = interaction.member as GuildMember;
    if (!(await isModerator(member))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط الوسطاء يمكنهم تغيير الأولوية.")], ephemeral: true });
      return;
    }
    const [updated] = await db.update(tickets).set({ priority, updatedAt: new Date() }).where(eq(tickets.id, ticket.id)).returning();
    const user = await interaction.client.users.fetch(ticket.userId);
    const newEmbed = buildTicketEmbed(updated, user.username, user.displayAvatarURL());
    await interaction.update({ embeds: [newEmbed], components: [buildTicketButtons(updated), buildPriorityMenu(ticket.id)] });
  }

  export async function bulkCloseTickets(
    client: Client, guildId: string, closedById: string
  ): Promise<{ closed: number; deleted: number }> {
    const openTickets = await db.query.tickets.findMany({
      where: and(eq(tickets.guildId, guildId), ne(tickets.status, "closed")),
    });

    let closed = 0;
    let deleted = 0;

    for (const ticket of openTickets) {
      try {
        const now = new Date();
        await db.update(tickets).set({
          status: "closed", closedBy: closedById, closedAt: now, updatedAt: now,
        }).where(eq(tickets.id, ticket.id));

        const channel = client.channels.cache.get(ticket.channelId) as TextChannel;
        if (channel) {
          try {
            await sendTranscript(client, { ...ticket, status: "closed", closedBy: closedById, closedAt: now }, channel);
          } catch {}
          try { await channel.delete(); deleted++; } catch {}
        }
        closed++;
      } catch (error) {
        console.error(`خطأ في إغلاق التكت ${ticket.ticketNumber}:`, error);
      }
    }

    return { closed, deleted };
  }
