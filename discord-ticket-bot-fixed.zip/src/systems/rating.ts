import { db, ratings } from "../database";
import { eq, avg, count, and } from "drizzle-orm";

// ============================================================
// نظام التقييم (1-5 نجوم)
// ============================================================

/**
 * حفظ تقييم جديد
 */
export async function saveRating(
  ticketId: number,
  guildId: string,
  userId: string,
  modId: string,
  rating: number,
  comment?: string
): Promise<void> {
  await db.insert(ratings).values({
    ticketId,
    guildId,
    userId,
    modId,
    rating,
    comment: comment || null,
  });
}

/**
 * الحصول على متوسط تقييمات وسيط
 */
export async function getModRating(
  modId: string,
  guildId: string
): Promise<{ avg: number; count: number }> {
  const result = await db
    .select({
      avgRating: avg(ratings.rating),
      totalCount: count(ratings.id),
    })
    .from(ratings)
    .where(and(eq(ratings.modId, modId), eq(ratings.guildId, guildId)));

  return {
    avg: parseFloat(result[0]?.avgRating ?? "0") || 0,
    count: Number(result[0]?.totalCount ?? 0),
  };
}

/**
 * الحصول على متوسط تقييمات السيرفر بالكامل
 */
export async function getGuildAverageRating(guildId: string): Promise<number> {
  const result = await db
    .select({ avgRating: avg(ratings.rating) })
    .from(ratings)
    .where(eq(ratings.guildId, guildId));

  return parseFloat(result[0]?.avgRating ?? "0") || 0;
}

/**
 * التحقق من أن المستخدم لم يقيّم هذا التكت بالفعل
 */
export async function hasRated(ticketId: number, userId: string): Promise<boolean> {
  const record = await db.query.ratings.findFirst({
    where: and(eq(ratings.ticketId, ticketId), eq(ratings.userId, userId)),
  });
  return !!record;
}
