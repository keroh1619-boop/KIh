// ============================================================
// نظام Cooldown (تأخير تنفيذ الأوامر)
// ============================================================

interface CooldownEntry {
  timestamp: number;
  command: string;
}

// خريطة Cooldowns: userId -> Map<command, timestamp>
const cooldowns = new Map<string, Map<string, number>>();

/**
 * التحقق من Cooldown وإضافته
 * @returns رسالة الخطأ إذا كان المستخدم في Cooldown، أو null إذا لم يكن
 */
export function checkCooldown(
  userId: string,
  command: string,
  cooldownSeconds: number
): string | null {
  const now = Date.now();

  if (!cooldowns.has(userId)) {
    cooldowns.set(userId, new Map());
  }

  const userCooldowns = cooldowns.get(userId)!;
  const lastUsed = userCooldowns.get(command);

  if (lastUsed) {
    const elapsed = (now - lastUsed) / 1000;
    const remaining = cooldownSeconds - elapsed;

    if (remaining > 0) {
      return `⏱️ يرجى الانتظار **${remaining.toFixed(1)}** ثانية قبل استخدام هذا الأمر مجدداً.`;
    }
  }

  userCooldowns.set(command, now);
  return null;
}

/**
 * إزالة Cooldown مستخدم معين
 */
export function resetCooldown(userId: string, command: string): void {
  cooldowns.get(userId)?.delete(command);
}

/**
 * تنظيف Cooldowns القديمة (تشغيل دوري)
 */
export function cleanupCooldowns(): void {
  const now = Date.now();
  const maxAge = 3600 * 1000; // ساعة واحدة

  for (const [userId, commands] of cooldowns) {
    for (const [command, timestamp] of commands) {
      if (now - timestamp > maxAge) {
        commands.delete(command);
      }
    }
    if (commands.size === 0) {
      cooldowns.delete(userId);
    }
  }
}

// تنظيف تلقائي كل ساعة
setInterval(cleanupCooldowns, 3600 * 1000);
