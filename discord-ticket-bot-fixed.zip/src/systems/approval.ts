// تم التطوير بواسطة كيرو

import {
    ButtonInteraction, TextChannel, PermissionFlagsBits, EmbedBuilder,
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ColorResolvable,
    ChatInputCommandInteraction, GuildMember,
  } from "discord.js";
  import { db, tickets, serverSettings } from "../database";
  import { eq } from "drizzle-orm";
  import { buildErrorEmbed, buildSuccessEmbed } from "../utils/embeds";
  import { sendLog } from "./logging";
  import { performClose } from "./tickets";
  import { Ticket } from "../database/schema";
  import { config } from "../config";
  import { hasMediatorRole, isPermissionManager } from "../utils/permissions";

  export async function requestApproval(
    interaction: ChatInputCommandInteraction
  ): Promise<void> {
    const channel = interaction.channel as TextChannel;
    const guildId = interaction.guildId!;
    const member = interaction.member as GuildMember;

    if (!(await hasMediatorRole(member))) {
      await interaction.reply({
        embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط لرول الوسيط.")],
        ephemeral: true,
      });
      return;
    }

    const ticket = await db.query.tickets.findFirst({
      where: eq(tickets.channelId, interaction.channelId),
    });

    if (!ticket || ticket.status === "closed") {
      await interaction.reply({
        embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط داخل رومات التكتات المفتوحة.")],
        ephemeral: true,
      });
      return;
    }

    const blocked = ticket.blockedMediators ?? [];
    if (blocked.includes(interaction.user.id)) {
      await interaction.reply({
        embeds: [buildErrorEmbed("❌ لقد تم رفض طلبك في هذا التكت مسبقاً.")],
        ephemeral: true,
      });
      return;
    }

    const settings = await db.query.serverSettings.findFirst({
      where: eq(serverSettings.guildId, guildId),
    });

    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
      .setColor(0xffa500 as ColorResolvable)
      .setTitle("📨 طلب إذن وساطة")
      .setDescription(
        `يطلب <@${interaction.user.id}> بدء وساطة في التكت <#${channel.id}>.

**هل توافق على بدء الوساطة؟**`
      )
      .addFields(
        { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
        { name: "👤 صاحب التكت", value: `<@${ticket.userId}>`, inline: true },
        { name: "🤝 الوسيط", value: `<@${interaction.user.id}>`, inline: true },
      )
      .setTimestamp();

    const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`approval_accept_${ticket.id}_${interaction.user.id}`)
        .setLabel("✅ قبول")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`approval_reject_${ticket.id}_${interaction.user.id}`)
        .setLabel("❌ رفض")
        .setStyle(ButtonStyle.Danger),
    );

    let mentionContent = `<@${config.ownerId}>`;
    if (settings?.permissionManagerRoleId) {
      mentionContent = `<@&${settings.permissionManagerRoleId}>`;
    }

    await channel.send({
      content: `📨 ${mentionContent} — طلب إذن وساطة يحتاج مراجعتك:`,
      embeds: [embed],
      components: [buttons],
    });

    await interaction.editReply({
      embeds: [buildSuccessEmbed("✅ تم إرسال طلب الإذن. يرجى انتظار الموافقة.")],
    });

    await sendLog(interaction.client, guildId, "approval_request", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id);
  }

  async function canApprove(interaction: ButtonInteraction): Promise<boolean> {
    if (interaction.user.id === config.ownerId) return true;

    const settings = await db.query.serverSettings.findFirst({
      where: eq(serverSettings.guildId, interaction.guildId!),
    });

    if (!settings?.permissionManagerRoleId) return false;

    try {
      const member = await interaction.guild!.members.fetch(interaction.user.id);
      return member.roles.cache.has(settings.permissionManagerRoleId);
    } catch {
      return false;
    }
  }

  export async function acceptApproval(
    interaction: ButtonInteraction,
    ticketId: number,
    mediatorId: string
  ): Promise<void> {
    if (!(await canApprove(interaction))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لا تملك صلاحية قبول هذا الطلب.")], ephemeral: true });
      return;
    }

    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket || ticket.status === "closed") {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ التكت غير موجود أو مغلق.")], ephemeral: true });
      return;
    }

    await interaction.update({
      embeds: [{
        color: 0x57f287,
        title: "✅ تم قبول طلب الوساطة",
        description: `قبل <@${interaction.user.id}> طلب وساطة <@${mediatorId}> في التكت #${ticket.ticketNumber}.`,
        timestamp: new Date().toISOString(),
      }],
      components: [],
    });

    const channel = interaction.channel as TextChannel;
    await channel.send({
      embeds: [{
        color: 0x57f287,
        title: "✅ تم قبول بدء الوساطة",
        description: `تم قبول بدء الوساطة، يمكنكم المتابعة الآن.
🤝 الوسيط: <@${mediatorId}>
✅ تمت الموافقة بواسطة: <@${interaction.user.id}>`,
        timestamp: new Date().toISOString(),
      }],
    });

    await sendLog(interaction.client, interaction.guildId!, "approval_accept", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط", value: `<@${mediatorId}>`, inline: true },
      { name: "✅ قبل بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id, mediatorId);
  }

  export async function rejectApproval(
    interaction: ButtonInteraction,
    ticketId: number,
    mediatorId: string
  ): Promise<void> {
    if (!(await canApprove(interaction))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ لا تملك صلاحية رفض هذا الطلب.")], ephemeral: true });
      return;
    }

    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket || ticket.status === "closed") {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ التكت غير موجود أو مغلق.")], ephemeral: true });
      return;
    }

    const blocked = [...(ticket.blockedMediators ?? [])];
    if (!blocked.includes(mediatorId)) blocked.push(mediatorId);
    await db.update(tickets).set({ blockedMediators: blocked, updatedAt: new Date() }).where(eq(tickets.id, ticketId));

    const channel = interaction.channel as TextChannel;
    try {
      await channel.permissionOverwrites.delete(mediatorId);
    } catch {}

    await interaction.update({
      embeds: [{
        color: 0xed4245,
        title: "❌ تم رفض طلب الوساطة",
        description: `رفض <@${interaction.user.id}> طلب وساطة <@${mediatorId}>.`,
        timestamp: new Date().toISOString(),
      }],
      components: [],
    });

    await channel.send({
      embeds: [{
        color: 0xed4245,
        title: "❌ تم رفض طلب الوساطة",
        description: `تم رفض طلب وساطة <@${mediatorId}> في هذا التكت.
لا يمكنه المشاركة في هذا التكت مجدداً.`,
        timestamp: new Date().toISOString(),
      }],
    });

    await sendLog(interaction.client, interaction.guildId!, "approval_reject", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط المرفوض", value: `<@${mediatorId}>`, inline: true },
      { name: "❌ رفض بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id, mediatorId);
  }

  export async function requestDoneApproval(
    interaction: ChatInputCommandInteraction
  ): Promise<void> {
    const channel = interaction.channel as TextChannel;
    const guildId = interaction.guildId!;
    const member = interaction.member as GuildMember;

    if (!(await hasMediatorRole(member))) {
      await interaction.reply({
        embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط لرول الوسيط.")],
        ephemeral: true,
      });
      return;
    }

    const ticket = await db.query.tickets.findFirst({
      where: eq(tickets.channelId, interaction.channelId),
    });

    if (!ticket || ticket.status === "closed" || ticket.status === "pending_approval") {
      await interaction.reply({
        embeds: [buildErrorEmbed("❌ هذا الأمر متاح فقط داخل رومات التكتات المفتوحة.")],
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply();

    await db.update(tickets).set({
      status: "pending_approval", doneBy: interaction.user.id, updatedAt: new Date(),
    }).where(eq(tickets.id, ticket.id));

    const settings = await db.query.serverSettings.findFirst({
      where: eq(serverSettings.guildId, guildId),
    });

    try {
      await channel.permissionOverwrites.edit(channel.guild.id, {
        SendMessages: false,
      });

      await channel.permissionOverwrites.edit(ticket.userId, {
        ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
      });

      if (ticket.claimedBy) {
        await channel.permissionOverwrites.edit(ticket.claimedBy, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
        });
      }

      if (settings?.supportRoleIds) {
        for (const roleId of settings.supportRoleIds) {
          try {
            await channel.permissionOverwrites.edit(roleId, {
              ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
            });
          } catch {}
        }
      }

      if (settings?.mediatorRoleId) {
        try {
          await channel.permissionOverwrites.edit(settings.mediatorRoleId, {
            ViewChannel: true, ReadMessageHistory: true, SendMessages: false,
          });
        } catch {}
      }

      if (settings?.permissionManagerRoleId) {
        await channel.permissionOverwrites.edit(settings.permissionManagerRoleId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: true,
        });
      }

      if (settings?.highAdminRoleId) {
        await channel.permissionOverwrites.edit(settings.highAdminRoleId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: true,
        });
      }

      const ownerMember = await channel.guild.members.fetch(config.ownerId).catch(() => null);
      if (ownerMember) {
        await channel.permissionOverwrites.edit(config.ownerId, {
          ViewChannel: true, ReadMessageHistory: true, SendMessages: true,
        });
      }
    } catch (error) {
      console.error("خطأ في قفل التكت:", error);
    }

    const embed = new EmbedBuilder()
      .setColor(0xffa500 as ColorResolvable)
      .setTitle("👍 تم — بانتظار الموافقة")
      .setDescription(
        `قام <@${interaction.user.id}> بتأكيد الانتهاء من التكت.
        
🔒 **تم قفل التكت** — لا يمكن لأحد الكتابة فيه.

⏳ بانتظار الموافقة أو الرفض من مسؤول الأذونات أو الأونر.`
      )
      .addFields(
        { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
        { name: "👤 صاحب التكت", value: `<@${ticket.userId}>`, inline: true },
        { name: "🤝 الوسيط", value: `<@${interaction.user.id}>`, inline: true },
      )
      .setTimestamp();

    const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`done_approve_${ticket.id}_${interaction.user.id}`)
        .setLabel("✅ موافقة")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`done_reject_${ticket.id}_${interaction.user.id}`)
        .setLabel("❌ رفض")
        .setStyle(ButtonStyle.Danger),
    );

    let mentionContent = `<@${config.ownerId}>`;
    if (settings?.permissionManagerRoleId) {
      mentionContent = `<@&${settings.permissionManagerRoleId}>`;
    }

    await interaction.editReply({
      content: `📨 ${mentionContent} — طلب موافقة على إغلاق التكت:`,
      embeds: [embed],
      components: [buttons],
    });

    await sendLog(interaction.client, guildId, "done_request", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id);
  }

  export async function handleDoneApprove(
    interaction: ButtonInteraction,
    ticketId: number,
    mediatorId: string
  ): Promise<void> {
    if (!(await canApprove(interaction))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط مسؤول الأذونات أو الأونر يمكنهم الموافقة.")], ephemeral: true });
      return;
    }

    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket || ticket.status === "closed") {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ التكت غير موجود أو مغلق بالفعل.")], ephemeral: true });
      return;
    }

    await db.update(tickets).set({
      approvedBy: interaction.user.id, updatedAt: new Date(),
    }).where(eq(tickets.id, ticketId));

    await interaction.update({
      embeds: [{
        color: 0x57f287,
        title: "✅ تمت الموافقة على إغلاق التكت",
        description: `✅ تمت الموافقة بواسطة: <@${interaction.user.id}>
🤝 الوسيط: <@${mediatorId}>
🏆 تم منح النقاط للوسيط.`,
        timestamp: new Date().toISOString(),
      }],
      components: [],
    });

    const channel = interaction.channel as TextChannel;
    await performClose(interaction.client, channel, ticket, interaction.user.id, false);

    await sendLog(interaction.client, interaction.guildId!, "done_approve", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط", value: `<@${mediatorId}>`, inline: true },
      { name: "✅ تمت الموافقة بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id, mediatorId);
  }

  export async function handleDoneReject(
    interaction: ButtonInteraction,
    ticketId: number,
    mediatorId: string
  ): Promise<void> {
    if (!(await canApprove(interaction))) {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ فقط مسؤول الأذونات أو الأونر يمكنهم الرفض.")], ephemeral: true });
      return;
    }

    const ticket = await db.query.tickets.findFirst({ where: eq(tickets.id, ticketId) });
    if (!ticket || ticket.status === "closed") {
      await interaction.reply({ embeds: [buildErrorEmbed("❌ التكت غير موجود أو مغلق بالفعل.")], ephemeral: true });
      return;
    }

    await interaction.update({
      embeds: [{
        color: 0xed4245,
        title: "❌ تم رفض إغلاق التكت",
        description: `❌ تم الرفض بواسطة: <@${interaction.user.id}>
🤝 الوسيط: <@${mediatorId}>
⚠️ لم يتم منح أي نقاط.`,
        timestamp: new Date().toISOString(),
      }],
      components: [],
    });

    const channel = interaction.channel as TextChannel;
    await performClose(interaction.client, channel, ticket, interaction.user.id, true);

    await sendLog(interaction.client, interaction.guildId!, "done_reject", [
      { name: "🎫 رقم التكت", value: `#${ticket.ticketNumber}`, inline: true },
      { name: "🤝 الوسيط", value: `<@${mediatorId}>`, inline: true },
      { name: "❌ رفض بواسطة", value: `<@${interaction.user.id}>`, inline: true },
    ], ticket.id, interaction.user.id, mediatorId);
  }
